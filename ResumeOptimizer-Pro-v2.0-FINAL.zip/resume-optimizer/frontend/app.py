"""
Resume Optimizer - Interface Gráfica
Aplicativo desktop para otimização de currículos
"""

import os
import sys
import json
import asyncio
from pathlib import Path
from datetime import datetime

import streamlit as st
import requests
from PIL import Image

# Configuração da página
st.set_page_config(
    page_title="Resume Optimizer Pro",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS Personalizado
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .score-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 20px;
        border-radius: 10px;
        color: white;
        text-align: center;
    }
    .score-number {
        font-size: 3rem;
        font-weight: bold;
    }
    .error-box {
        background-color: #ffebee;
        border-left: 5px solid #f44336;
        padding: 15px;
        margin: 10px 0;
        border-radius: 5px;
    }
    .success-box {
        background-color: #e8f5e9;
        border-left: 5px solid #4caf50;
        padding: 15px;
        margin: 10px 0;
        border-radius: 5px;
    }
    .suggestion-box {
        background-color: #e3f2fd;
        border-left: 5px solid #2196f3;
        padding: 15px;
        margin: 10px 0;
        border-radius: 5px;
    }
</style>
""", unsafe_allow_html=True)

# Estado da sessão
if 'cv_data' not in st.session_state:
    st.session_state.cv_data = None
if 'analysis' not in st.session_state:
    st.session_state.analysis = None
if 'optimized' not in st.session_state:
    st.session_state.optimized = None
if 'api_url' not in st.session_state:
    st.session_state.api_url = "http://localhost:8000"

# Sidebar
with st.sidebar:
    st.image("https://img.icons8.com/color/96/000000/resume.png", width=100)
    st.title("⚙️ Configurações")

    # API Key
    api_key = st.text_input("OpenAI API Key", type="password", 
                           help="Necessário para análise com IA")
    if api_key:
        os.environ["OPENAI_API_KEY"] = api_key

    # Target Role
    st.session_state.target_role = st.text_input(
        "Cargo Alvo",
        placeholder="Ex: Desenvolvedor Python Sênior"
    )

    # Job Description
    st.session_state.job_description = st.text_area(
        "Descrição da Vaga (opcional)",
        placeholder="Cole aqui a descrição da vaga para matching...",
        height=150
    )

    st.markdown("---")
    st.markdown("### 🚀 Automação")
    st.markdown("Preencha automaticamente sites de emprego")

    platform = st.selectbox(
        "Plataforma",
        ["Gupy", "Catho", "LinkedIn", "Indeed"]
    )

    job_url = st.text_input(
        "URL da Vaga",
        placeholder="https://..."
    )

# Header
st.markdown('<h1 class="main-header">📄 Resume Optimizer Pro</h1>', unsafe_allow_html=True)
st.markdown("<h3 style='text-align: center; color: #666;'>Análise, Otimização e Automação de Currículos com IA</h3>", unsafe_allow_html=True)

# Tabs
tab1, tab2, tab3, tab4 = st.tabs(["📤 Upload", "📊 Análise", "✨ Otimização", "🤖 Automação"])

# Tab 1: Upload
with tab1:
    st.header("Faça upload do seu currículo")

    uploaded_file = st.file_uploader(
        "Escolha um arquivo (PDF, DOCX, ou imagem)",
        type=['pdf', 'docx', 'doc', 'jpg', 'jpeg', 'png']
    )

    if uploaded_file is not None:
        col1, col2 = st.columns(2)

        with col1:
            st.info(f"📎 Arquivo: **{uploaded_file.name}**")
            st.info(f"📊 Tamanho: {uploaded_file.size / 1024:.1f} KB")

        with col2:
            if st.button("🚀 Processar Currículo", type="primary", use_container_width=True):
                with st.spinner("Processando..."):
                    try:
                        # Salvar arquivo
                        temp_dir = Path("temp")
                        temp_dir.mkdir(exist_ok=True)
                        file_path = temp_dir / uploaded_file.name

                        with open(file_path, "wb") as f:
                            f.write(uploaded_file.getvalue())

                        # Importar e usar extrator
                        sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))
                        from api.services.pdf_extractor import extract_cv

                        # Extrair dados
                        cv_data = extract_cv(str(file_path))
                        st.session_state.cv_data = cv_data

                        # Mostrar preview
                        st.success("✅ Currículo processado com sucesso!")

                        with st.expander("👁️ Visualizar dados extraídos"):
                            st.json(cv_data)

                        # Limpar arquivo
                        file_path.unlink()

                    except Exception as e:
                        st.error(f"❌ Erro ao processar: {str(e)}")

# Tab 2: Análise
with tab2:
    st.header("Análise do Currículo")

    if st.session_state.cv_data is None:
        st.warning("⚠️ Faça upload do currículo primeiro na aba 'Upload'")
    else:
        if st.button("🔍 Analisar com IA", type="primary"):
            if not api_key:
                st.error("❌ Por favor, insira sua OpenAI API Key na sidebar")
            else:
                with st.spinner("Analisando currículo com IA... Isso pode levar alguns segundos"):
                    try:
                        sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))
                        from api.services.ai_analyzer import CVAnalyzer

                        analyzer = CVAnalyzer(api_key=api_key)

                        analysis = asyncio.run(analyzer.analyze(
                            st.session_state.cv_data["raw_text"],
                            target_role=st.session_state.get("target_role"),
                            job_description=st.session_state.get("job_description")
                        ))

                        st.session_state.analysis = analysis.to_dict()
                        st.success("✅ Análise concluída!")

                    except Exception as e:
                        st.error(f"❌ Erro na análise: {str(e)}")

        if st.session_state.analysis:
            analysis = st.session_state.analysis

            # Scores
            col1, col2, col3 = st.columns(3)

            with col1:
                st.markdown(f"""
                <div class="score-card">
                    <div class="score-number">{analysis.get("score_geral", 0)}</div>
                    <div>Score Geral</div>
                </div>
                """, unsafe_allow_html=True)

            with col2:
                st.markdown(f"""
                <div class="score-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                    <div class="score-number">{analysis.get("score_ats", 0)}</div>
                    <div>Compatibilidade ATS</div>
                </div>
                """, unsafe_allow_html=True)

            with col3:
                compat = analysis.get("compatibilidade_vaga", {})
                match = compat.get("match_percentual", 0) if compat else 0
                st.markdown(f"""
                <div class="score-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                    <div class="score-number">{match}%</div>
                    <div>Match com Vaga</div>
                </div>
                """, unsafe_allow_html=True)

            st.markdown("---")

            # Erros críticos
            if analysis.get("erros_criticos"):
                st.subheader("🚨 Erros Críticos")
                for error in analysis["erros_criticos"]:
                    st.markdown(f"""
                    <div class="error-box">
                        <strong>{error.get("tipo", "Erro").upper()}</strong> - {error.get("local", "")}<br>
                        {error.get("descricao", "")}
                    </div>
                    """, unsafe_allow_html=True)

            # Pontos fortes
            if analysis.get("pontos_fortes"):
                st.subheader("💪 Pontos Fortes")
                for point in analysis["pontos_fortes"]:
                    st.markdown(f"""
                    <div class="success-box">
                        ✅ {point}
                    </div>
                    """, unsafe_allow_html=True)

            # Sugestões
            if analysis.get("sugestoes"):
                st.subheader("💡 Sugestões de Melhoria")
                for sug in analysis["sugestoes"]:
                    st.markdown(f"""
                    <div class="suggestion-box">
                        <strong>{sug.get("secao", "Geral")}</strong><br>
                        {sug.get("acao", "")}<br>
                        <em>Exemplo: {sug.get("exemplo", "")}</em>
                    </div>
                    """, unsafe_allow_html=True)

            # Análise RH
            with st.expander("👔 Análise do Recrutador"):
                rh = analysis.get("analise_rh", {})
                st.write(f"**Perfil Detectado:** {rh.get('perfil_detectado', 'N/A')}")
                st.write(f"**Nível:** {rh.get('nivel_senioridade', 'N/A')}")
                st.write(f"**Readiness:** {rh.get('readiness_para_vaga', 0)}%")
                if rh.get('pontos_atencao'):
                    st.write("**Pontos de Atenção:**")
                    for p in rh['pontos_atencao']:
                        st.write(f"- {p}")

# Tab 3: Otimização
with tab3:
    st.header("Otimização do Currículo")

    if st.session_state.analysis is None:
        st.warning("⚠️ Realize a análise primeiro na aba 'Análise'")
    else:
        if st.button("✨ Gerar Currículo Otimizado", type="primary"):
            with st.spinner("Otimizando com IA..."):
                try:
                    sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))
                    from api.services.cv_optimizer import CVOptimizer

                    optimizer = CVOptimizer(api_key=api_key)

                    optimized = asyncio.run(optimizer.optimize(
                        st.session_state.cv_data,
                        st.session_state.analysis,
                        target_role=st.session_state.get("target_role"),
                        job_description=st.session_state.get("job_description")
                    ))

                    st.session_state.optimized = optimized
                    st.success("✅ Currículo otimizado gerado!")

                except Exception as e:
                    st.error(f"❌ Erro na otimização: {str(e)}")

        if st.session_state.optimized:
            opt = st.session_state.optimized

            col1, col2 = st.columns(2)

            with col1:
                st.metric("Score Original", opt.score_original)

            with col2:
                st.metric("Score Otimizado", opt.score_otimizado, 
                         delta=f"+{opt.score_otimizado - opt.score_original}")

            # Preview do currículo otimizado
            st.subheader("📄 Preview do Currículo Otimizado")
            st.markdown(opt.content_markdown)

            # Download
            col1, col2 = st.columns(2)

            with col1:
                st.download_button(
                    label="📥 Download Markdown",
                    data=opt.content_markdown,
                    file_name=f"curriculo_otimizado_{datetime.now().strftime('%Y%m%d')}.md",
                    mime="text/markdown"
                )

            with col2:
                st.download_button(
                    label="📥 Download HTML",
                    data=opt.content_html,
                    file_name=f"curriculo_otimizado_{datetime.now().strftime('%Y%m%d')}.html",
                    mime="text/html"
                )

            # Otimizações aplicadas
            with st.expander("🔧 Otimizações Aplicadas"):
                for opt_item in opt.otimizacoes_aplicadas:
                    st.write(f"- {opt_item}")

                st.write("**Palavras-chave inseridas:**")
                for kw in opt.palavras_chave_inseridas:
                    st.write(f"- {kw}")

# Tab 4: Automação
with tab4:
    st.header("Automação de Candidaturas")

    st.info("🤖 Esta funcionalidade preenche automaticamente formulários de sites de emprego")

    if not job_url:
        st.warning("⚠️ Insira a URL da vaga na sidebar")
    else:
        st.write(f"**Plataforma:** {platform}")
        st.write(f"**URL:** {job_url}")

        if st.button("🚀 Iniciar Automação", type="primary"):
            if st.session_state.cv_data is None:
                st.error("❌ Faça upload do currículo primeiro")
            else:
                st.info("⚠️ A automação abrirá um navegador. Faça login manualmente quando solicitado.")

                progress_bar = st.progress(0)
                status_text = st.empty()

                try:
                    status_text.text("Iniciando navegador...")
                    progress_bar.progress(10)

                    # Aqui chamaria a automação real
                    # Por segurança, vamos apenas simular no exemplo

                    status_text.text("Navegando para a vaga...")
                    progress_bar.progress(30)

                    status_text.text("Aguardando login do usuário...")
                    progress_bar.progress(50)

                    status_text.text("Preenchendo formulário...")
                    progress_bar.progress(75)

                    status_text.text("Finalizando candidatura...")
                    progress_bar.progress(100)

                    st.success("✅ Automação concluída! Verifique o navegador.")

                except Exception as e:
                    st.error(f"❌ Erro na automação: {str(e)}")

# Footer
st.markdown("---")
st.markdown("<p style='text-align: center; color: #666;'>Resume Optimizer Pro v1.0 | Desenvolvido com ❤️ e IA</p>", unsafe_allow_html=True)
