#!/usr/bin/env python3
"""
RESUME OPTIMIZER PRO v1.0
Sistema Completo de Análise e Otimização de Currículos com IA
"""

import os
import sys
import json
import asyncio
import tempfile
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any

# Verificar e instalar dependências automaticamente
def check_and_install_deps():
    """Verifica e instala dependências necessárias"""
    required = {
        'streamlit': 'streamlit',
        'openai': 'openai',
        'pdfplumber': 'pdfplumber',
        'reportlab': 'reportlab',
        'PyPDF2': 'PyPDF2',
        'PIL': 'Pillow',
    }

    missing = []
    for module, package in required.items():
        try:
            __import__(module)
        except ImportError:
            missing.append(package)

    if missing:
        print(f"📦 Instalando dependências: {', '.join(missing)}")
        import subprocess
        subprocess.run([sys.executable, "-m", "pip", "install", "-q"] + missing)
        print("✅ Dependências instaladas!")

# Verificar dependências
check_and_install_deps()

# Imports após verificação
import streamlit as st
from openai import AsyncOpenAI
import pdfplumber
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

# ============== CONFIGURAÇÃO ==============
st.set_page_config(
    page_title="Resume Optimizer Pro",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS Personalizado
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 1rem;
    }
    .score-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 20px;
        border-radius: 15px;
        color: white;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .score-number {
        font-size: 3rem;
        font-weight: bold;
    }
    .error-box {
        background-color: #ffebee;
        border-left: 5px solid #f44336;
        padding: 15px;
        margin: 10px 0;
        border-radius: 5px;
    }
    .success-box {
        background-color: #e8f5e9;
        border-left: 5px solid #4caf50;
        padding: 15px;
        margin: 10px 0;
        border-radius: 5px;
    }
    .suggestion-box {
        background-color: #e3f2fd;
        border-left: 5px solid #2196f3;
        padding: 15px;
        margin: 10px 0;
        border-radius: 5px;
    }
    .stButton>button {
        width: 100%;
        border-radius: 10px;
        height: 3em;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

# ============== CLASSES ==============

@dataclass
class ExtractedCV:
    raw_text: str
    nome: str = ""
    email: str = ""
    telefone: str = ""
    linkedin: str = ""
    experiencias: List[Dict] = None
    educacao: List[Dict] = None
    habilidades: List[str] = None

    def __post_init__(self):
        if self.experiencias is None:
            self.experiencias = []
        if self.educacao is None:
            self.educacao = []
        if self.habilidades is None:
            self.habilidades = []

    def to_dict(self):
        return asdict(self)


class PDFExtractor:
    """Extrator de PDF simplificado"""

    def extract(self, file_path: str) -> ExtractedCV:
        text_parts = []

        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    text_parts.append(text)

        raw_text = "\n".join(text_parts)

        # Extração básica de dados
        cv = ExtractedCV(raw_text=raw_text)
        cv.nome = self._extract_name(raw_text)
        cv.email = self._extract_email(raw_text)
        cv.telefone = self._extract_phone(raw_text)
        cv.linkedin = self._extract_linkedin(raw_text)
        cv.habilidades = self._extract_skills(raw_text)

        return cv

    def _extract_name(self, text: str) -> str:
        lines = [l.strip() for l in text.split('\n') if l.strip()]
        for line in lines[:5]:
            if len(line) > 3 and '@' not in line and not any(c.isdigit() for c in line[:10]):
                return line.title()
        return ""

    def _extract_email(self, text: str) -> str:
        import re
        match = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
        return match.group(0) if match else ""

    def _extract_phone(self, text: str) -> str:
        import re
        match = re.search(r'(?:\+55\s?)?(?:\(?\d{2}\)?\s?)?(?:9\d{4}|\d{4})[-.\s]?\d{4}', text)
        return match.group(0) if match else ""

    def _extract_linkedin(self, text: str) -> str:
        import re
        match = re.search(r'linkedin\.com/in/([a-zA-Z0-9-]+)', text, re.IGNORECASE)
        return f"linkedin.com/in/{match.group(1)}" if match else ""

    def _extract_skills(self, text: str) -> List[str]:
        tech_keywords = [
            'python', 'java', 'javascript', 'typescript', 'react', 'node', 'sql',
            'aws', 'azure', 'docker', 'kubernetes', 'git', 'agile', 'scrum',
            'excel', 'power bi', 'tableau', 'liderança', 'gestão', 'projetos'
        ]
        text_lower = text.lower()
        found = [kw.title() for kw in tech_keywords if kw in text_lower]
        return list(set(found))[:15]


class CVAnalyzer:
    """Analisador com OpenAI"""

    def __init__(self, api_key: str):
        self.client = AsyncOpenAI(api_key=api_key)

    async def analyze(self, cv_text: str, target_role: str = None, job_desc: str = None) -> Dict:
        system_prompt = """Você é um painel de 3 especialistas em RH:
👔 RECRUTADOR TÉCNICO - Analisa skills e adequação
📊 ESPECIALISTA ATS - Verifica compatibilidade com sistemas
✍️ COPYWRITER - Avalia storytelling e impacto

Retorne análise em JSON estruturado."""

        user_prompt = f"""Analise este currículo:

{cv_text[:6000]}

Cargo Alvo: {target_role or 'Não especificado'}
{'Descrição da Vaga: ' + job_desc if job_desc else ''}

Retorne JSON com:
- score_geral (0-100)
- score_ats (0-100)
- erros_criticos (lista)
- pontos_fortes (lista)
- pontos_fracos (lista)
- sugestoes (lista com ação e exemplo)
- palavras_chave_faltantes (lista)
- analise_rh (perfil, nivel, readiness)
- analise_ats (compatibilidade, problemas, recomendacoes)"""

        response = await self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            response_format={"type": "json_object"},
            temperature=0.3
        )

        return json.loads(response.choices[0].message.content)


class CVOptimizer:
    """Otimizador com OpenAI"""

    def __init__(self, api_key: str):
        self.client = AsyncOpenAI(api_key=api_key)

    async def optimize(self, cv_data: Dict, analysis: Dict, target_role: str = None) -> Dict:
        system_prompt = """Você é um escritor executivo sênior. Reescreva currículos seguindo:
1. Action verbs no início
2. Métricas quantificadas
3. STAR Method
4. Keywords ATS
5. Máximo 2 páginas"""

        user_prompt = f"""Reescreva este currículo de forma profissional:

ORIGINAL:
{cv_data.get('raw_text', '')[:4000]}

PROBLEMAS IDENTIFICADOS:
{json.dumps(analysis.get('pontos_fracos', []), ensure_ascii=False)}

KEYWORDS A INSERIR:
{json.dumps(analysis.get('palavras_chave_faltantes', []), ensure_ascii=False)}

CARGO ALVO: {target_role or 'Não especificado'}

Retorne:
1. Currículo completo em Markdown
2. JSON com otimizacoes_aplicadas, palavras_chave_inseridas, score_estimado_original, score_estimado_otimizado"""

        response = await self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.4
        )

        content = response.choices[0].message.content

        # Separar markdown do JSON
        if "```json" in content:
            parts = content.split("```json")
            markdown = parts[0].replace("```markdown", "").replace("```", "").strip()
            json_part = parts[1].replace("```", "").strip()
            metadata = json.loads(json_part)
        else:
            markdown = content
            metadata = {}

        return {
            "markdown": markdown,
            "html": self._markdown_to_html(markdown),
            **metadata
        }

    def _markdown_to_html(self, markdown: str) -> str:
        import re
        html = markdown
        html = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'^- (.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
        return f"<html><body>{html}</body></html>"

    def generate_pdf(self, markdown: str, output_path: str):
        """Gera PDF do currículo"""
        doc = SimpleDocTemplate(output_path, pagesize=A4,
                               rightMargin=2*72, leftMargin=2*72,
                               topMargin=2*72, bottomMargin=2*72)

        styles = getSampleStyleSheet()
        story = []

        # Estilos personalizados
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=20,
            textColor=colors.HexColor('#2c3e50'),
            spaceAfter=12
        )

        for line in markdown.split('\n'):
            line = line.strip()
            if not line:
                story.append(Spacer(1, 12))
            elif line.startswith('# ') and not line.startswith('##'):
                story.append(Paragraph(line.replace('# ', ''), title_style))
            elif line.startswith('## '):
                story.append(Paragraph(line.replace('## ', ''), styles['Heading2']))
            elif line.startswith('- '):
                story.append(Paragraph(f"• {line.replace('- ', '')}", styles['BodyText']))
            else:
                story.append(Paragraph(line, styles['BodyText']))

        doc.build(story)


# ============== INTERFACE STREAMLIT ==============

def main():
    # Header
    st.markdown('<h1 class="main-header">📄 Resume Optimizer Pro</h1>', unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; font-size: 1.2em; color: #666;'>Análise e Otimização de Currículos com IA</p>", unsafe_allow_html=True)

    # Sidebar
    with st.sidebar:
        st.image("https://img.icons8.com/color/96/000000/resume.png", width=80)
        st.title("⚙️ Configurações")

        api_key = st.text_input("🔑 OpenAI API Key", type="password",
                               help="Obtenha em platform.openai.com")
        if api_key:
            os.environ["OPENAI_API_KEY"] = api_key

        st.markdown("---")
        target_role = st.text_input("🎯 Cargo Alvo", 
                                   placeholder="Ex: Desenvolvedor Python Sênior")
        job_description = st.text_area("📝 Descrição da Vaga (opcional)",
                                      placeholder="Cole a descrição para matching...",
                                      height=150)

        st.markdown("---")
        st.markdown("### 📊 Sobre")
        st.markdown("Versão 1.0")
        st.markdown("Desenvolvido com ❤️ e IA")

    # Tabs
    tab1, tab2, tab3 = st.tabs(["📤 Upload & Análise", "✨ Otimização", "📥 Download"])

    # Estado
    if 'cv_data' not in st.session_state:
        st.session_state.cv_data = None
    if 'analysis' not in st.session_state:
        st.session_state.analysis = None
    if 'optimized' not in st.session_state:
        st.session_state.optimized = None

    # Tab 1: Upload e Análise
    with tab1:
        st.header("Faça upload do seu currículo")

        uploaded = st.file_uploader("Escolha um arquivo (PDF)", type=['pdf'])

        if uploaded:
            col1, col2 = st.columns([1, 2])

            with col1:
                st.info(f"📎 {uploaded.name}\n📊 {uploaded.size/1024:.1f} KB")

            with col2:
                if st.button("🚀 Processar Currículo", type="primary"):
                    if not api_key:
                        st.error("❌ Insira sua OpenAI API Key na sidebar")
                    else:
                        with st.spinner("Processando..."):
                            # Salvar arquivo temporário
                            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
                            temp_file.write(uploaded.getvalue())
                            temp_file.close()

                            # Extrair
                            extractor = PDFExtractor()
                            st.session_state.cv_data = extractor.extract(temp_file.name).to_dict()

                            os.unlink(temp_file.name)
                            st.success("✅ Currículo processado!")

            if st.session_state.cv_data:
                with st.expander("👁️ Dados Extraídos"):
                    st.json(st.session_state.cv_data)

                if st.button("🔍 Analisar com IA"):
                    with st.spinner("Analisando com GPT-4..."):
                        analyzer = CVAnalyzer(api_key)
                        st.session_state.analysis = asyncio.run(analyzer.analyze(
                            st.session_state.cv_data['raw_text'],
                            target_role=target_role,
                            job_desc=job_description
                        ))
                        st.success("✅ Análise concluída!")

                if st.session_state.analysis:
                    analysis = st.session_state.analysis

                    # Scores
                    cols = st.columns(3)
                    with cols[0]:
                        st.markdown(f'<div class="score-card"><div class="score-number">{analysis.get("score_geral", 0)}</div><div>Score Geral</div></div>', 
                                  unsafe_allow_html=True)
                    with cols[1]:
                        st.markdown(f'<div class="score-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);"><div class="score-number">{analysis.get("score_ats", 0)}</div><div>Compatibilidade ATS</div></div>', 
                                  unsafe_allow_html=True)
                    with cols[2]:
                        match = analysis.get("compatibilidade_vaga", {}).get("match_percentual", 0) if analysis.get("compatibilidade_vaga") else 0
                        st.markdown(f'<div class="score-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);"><div class="score-number">{match}%</div><div>Match Vaga</div></div>', 
                                  unsafe_allow_html=True)

                    st.markdown("---")

                    # Erros
                    if analysis.get("erros_criticos"):
                        st.subheader("🚨 Erros Críticos")
                        for err in analysis["erros_criticos"][:5]:
                            st.markdown(f'<div class="error-box"><strong>{err.get("tipo", "").upper()}</strong><br>{err.get("descricao", "")}</div>', 
                                      unsafe_allow_html=True)

                    # Pontos fortes
                    if analysis.get("pontos_fortes"):
                        st.subheader("💪 Pontos Fortes")
                        for pt in analysis["pontos_fortes"][:5]:
                            st.markdown(f'<div class="success-box">✅ {pt}</div>', 
                                      unsafe_allow_html=True)

                    # Sugestões
                    if analysis.get("sugestoes"):
                        st.subheader("💡 Sugestões")
                        for sug in analysis["sugestoes"][:5]:
                            st.markdown(f'<div class="suggestion-box"><strong>{sug.get("secao", "Geral")}</strong><br>{sug.get("acao", "")}<br><em>Ex: {sug.get("exemplo", "")}</em></div>', 
                                      unsafe_allow_html=True)

    # Tab 2: Otimização
    with tab2:
        st.header("Otimização do Currículo")

        if not st.session_state.analysis:
            st.warning("⚠️ Realize a análise primeiro na aba 'Upload & Análise'")
        else:
            if st.button("✨ Gerar Currículo Otimizado", type="primary"):
                with st.spinner("Otimizando com IA..."):
                    optimizer = CVOptimizer(api_key)
                    st.session_state.optimized = asyncio.run(optimizer.optimize(
                        st.session_state.cv_data,
                        st.session_state.analysis,
                        target_role=target_role
                    ))
                    st.success("✅ Currículo otimizado gerado!")

            if st.session_state.optimized:
                opt = st.session_state.optimized

                col1, col2 = st.columns(2)
                col1.metric("Score Original", opt.get("score_estimado_original", 0))
                col2.metric("Score Otimizado", opt.get("score_estimado_otimizado", 0),
                           delta=f"+{opt.get('score_estimado_otimizado', 0) - opt.get('score_estimado_original', 0)}")

                st.subheader("📄 Preview")
                st.markdown(opt["markdown"])

    # Tab 3: Download
    with tab3:
        st.header("Download do Currículo Otimizado")

        if not st.session_state.optimized:
            st.warning("⚠️ Gere a versão otimizada primeiro")
        else:
            opt = st.session_state.optimized

            col1, col2, col3 = st.columns(3)

            with col1:
                st.download_button(
                    "📄 Download Markdown",
                    opt["markdown"],
                    f"curriculo_otimizado_{datetime.now().strftime('%Y%m%d')}.md",
                    "text/markdown"
                )

            with col2:
                st.download_button(
                    "🌐 Download HTML",
                    opt["html"],
                    f"curriculo_otimizado_{datetime.now().strftime('%Y%m%d')}.html",
                    "text/html"
                )

            with col3:
                # Gerar PDF
                if st.button("📕 Gerar PDF"):
                    with st.spinner("Gerando PDF..."):
                        pdf_path = tempfile.mktemp(suffix='.pdf')
                        optimizer = CVOptimizer(api_key)
                        optimizer.generate_pdf(opt["markdown"], pdf_path)

                        with open(pdf_path, "rb") as f:
                            st.download_button(
                                "📥 Baixar PDF",
                                f.read(),
                                f"curriculo_otimizado_{datetime.now().strftime('%Y%m%d')}.pdf",
                                "application/pdf"
                            )

                        os.unlink(pdf_path)

            # Otimizações aplicadas
            with st.expander("🔧 Detalhes das Otimizações"):
                st.write("**Otimizações aplicadas:**")
                for item in opt.get("otimizacoes_aplicadas", []):
                    st.write(f"- {item}")

                st.write("**Palavras-chave inseridas:**")
                for kw in opt.get("palavras_chave_inseridas", []):
                    st.write(f"- {kw}")

if __name__ == "__main__":
    main()
