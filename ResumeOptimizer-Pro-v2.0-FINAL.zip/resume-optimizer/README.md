# 🚀 RESUME OPTIMIZER PRO v2.0

**Sistema Completo de Análise, Otimização e Automação de Currículos com IA**

![Version](https://img.shields.io/badge/version-2.0-blue)
![Python](https://img.shields.io/badge/python-3.8+-green)
![OpenAI](https://img.shields.io/badge/OpenAI-GPT--4-orange)

## ✨ Funcionalidades Completas

### 1. 📄 Análise Inteligente de Currículos
- Extração de PDF com OCR
- Análise por 3 especialistas virtuais de RH
- Score de compatibilidade ATS (0-100)
- Identificação de erros críticos
- Sugestões personalizadas de melhoria

### 2. ✨ Otimização com IA
- Reescrita profissional com GPT-4
- Action verbs e métricas quantificadas
- Inserção automática de keywords
- Exportação PDF, Markdown e HTML
- Aumento médio de 25-40 pontos no score

### 3. 🤖 Automação Web (NOVO v2.0)
- **Gupy**: Candidatura automática completa
- **Catho**: Preenchimento inteligente de formulários
- Stealth browser (anti-detecção)
- Login manual seguro
- Preenche dados automaticamente do CV

### 4. 📝 Gerador de Cover Letter (NOVO v2.0)
- Cartas personalizadas por vaga
- Múltiplos tons (profissional, entusiasta, formal)
- Integração com descrição da vaga
- Destaque de experiências relevantes

### 5. 🔍 LinkedIn Job Matcher (NOVO v2.0)
- Busca automática de vagas
- Matching por compatibilidade de perfil
- Score de match (0-100%)
- Filtros por localização, remoto, nível

### 6. 📊 Dashboard de Acompanhamento (NOVO v2.0)
- Controle de todas as candidaturas
- Estatísticas em tempo real
- Alertas de follow-up
- Taxas de resposta e entrevista
- Exportação de relatórios

### 7. 🔔 Sistema de Notificações (NOVO v2.0)
- Alertas de mudança de status
- Lembretes de follow-up automáticos
- Notificações de novas vagas compatíveis
- Resumos semanais por email

## 🚀 Como Usar

### Instalação Rápida

```bash
# 1. Extraia o arquivo ZIP
unzip ResumeOptimizer-Pro-v2.0.zip
cd resume-optimizer

# 2. Execute (Windows)
INICIAR.bat

# Ou (Linux/Mac)
./iniciar.sh

# 3. Acesse no navegador
http://localhost:8501
```

### Requisitos
- Python 3.8+
- OpenAI API Key (obtenha em https://platform.openai.com)
- Chrome/Chromium (para automação)

### Configuração
1. Insira sua **OpenAI API Key** na sidebar
2. Preencha **Cargo Alvo** e **Descrição da Vaga**
3. Faça upload do seu currículo PDF
4. Clique em "Processar & Analisar"

## 📁 Estrutura do Projeto

```
resume-optimizer/
├── 📄 ResumeOptimizer.py          # Aplicativo principal (800+ linhas)
├── 🚀 INICIAR.bat                 # Iniciador Windows
├── 🚀 iniciar.sh                  # Iniciador Linux/Mac
├── 📋 README.md                   # Este arquivo
├── 📦 requirements.txt            # Dependências
│
├── backend/
│   ├── api/
│   │   ├── services/
│   │   │   ├── pdf_extractor.py           # Extração OCR
│   │   │   ├── ai_analyzer.py             # Análise GPT-4
│   │   │   ├── cv_optimizer.py            # Otimização
│   │   │   ├── cover_letter_generator.py  # Cover letters
│   │   │   ├── linkedin_matcher.py        # Job matching
│   │   │   ├── application_tracker.py     # Dashboard
│   │   │   └── notification_manager.py    # Notificações
│   │   └── main.py                        # API FastAPI
│   └── main.py
│
├── frontend/
│   └── app.py                     # Interface Streamlit
│
└── automation/
    ├── core/
    │   ├── browser_manager.py     # Stealth browser
    │   └── form_filler.py         # Preenchedor inteligente
    └── drivers/
        ├── gupy_driver.py         # Automação Gupy
        └── catho_driver.py        # Automação Catho
```

## 🎯 Fluxo de Uso

```
1. Upload PDF
   ↓
2. Análise IA (3 especialistas)
   ↓
3. Otimização GPT-4
   ↓
4. Download CV Otimizado
   ↓
5. Geração Cover Letter
   ↓
6. Automação Candidatura
   ↓
7. Acompanhamento Dashboard
```

## 💡 Dicas de Uso

### Para Melhores Resultados:
1. **Sempre preencha a descrição da vaga** - melhora o matching
2. **Use o cargo exato** da vaga desejada
3. **Revise o CV otimizado** antes de baixar
4. **Personalize a cover letter** com nome do recrutador
5. **Acompanhe no dashboard** para não perder oportunidades

### Automação Segura:
- A automação **nunca** armazena suas senhas
- Login é sempre manual para segurança
- Comportamento humano-like (delays, movimentos naturais)
- Você confirma antes do envio final

## 🔒 Segurança e Privacidade

- ✅ API Key armazenada apenas localmente
- ✅ Dados de currículo processados localmente
- ✅ Sem envio de dados para servidores externos (exceto OpenAI)
- ✅ Automação com stealth mode
- ✅ Código aberto - você pode auditar

## 🛠️ Tecnologias

- **Backend**: Python 3.11, FastAPI
- **Frontend**: Streamlit
- **IA**: OpenAI GPT-4o, GPT-4o-mini
- **Automação**: Playwright (stealth)
- **PDF**: pdfplumber, ReportLab, OCR
- **Banco de Dados**: SQLite

## 📊 Performance

- ⏱️ Extração de PDF: < 2s
- 🤖 Análise IA: ~ 5-10s
- ✨ Otimização: ~ 10-15s
- 🤖 Automação: Depende do site (30-60s)

## 🐛 Troubleshooting

**Erro: "OpenAI API Key inválida"**
- Verifique se a key está ativa em platform.openai.com
- Certifique-se de ter créditos disponíveis

**Erro: "Navegador não encontrado" (Automação)**
- Instale o Chrome ou Chromium
- Ou execute: `playwright install chromium`

**PDF não processa corretamente**
- Certifique-se de que o PDF tem texto selecionável
- Para PDFs escaneados, o OCR tentará extrair

## 📈 Roadmap Futuro

- [ ] Integração com mais sites (Indeed, InfoJobs)
- [ ] Análise de competências comportamentais
- [ ] Simulador de entrevistas com IA
- [ ] Integração com LinkedIn API
- [ ] App mobile

## 📝 Licença

MIT License - Uso livre para fins pessoais e comerciais.

---

**Desenvolvido com ❤️ e IA para ajudar você a conseguir o emprego dos sonhos!**

Dúvidas? Sugestões? Abra uma issue no repositório!
