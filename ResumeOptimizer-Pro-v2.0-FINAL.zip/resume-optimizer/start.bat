@echo off
chcp 65001 >nul
echo ============================================
echo    RESUME OPTIMIZER PRO
echo    Analise e Otimize seu Curriculo com IA
echo ============================================
echo.

REM Verificar Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado. Por favor, instale o Python 3.8+
    pause
    exit /b 1
)

REM Verificar dependencias
if not exist "venv" (
    echo [INFO] Criando ambiente virtual...
    python -m venv venv
)

echo [INFO] Ativando ambiente virtual...
call venv\Scripts\activate.bat

echo [INFO] Instalando dependencias...
pip install -q -r requirements.txt

echo [INFO] Iniciando aplicacao...
python launcher.py

pause
