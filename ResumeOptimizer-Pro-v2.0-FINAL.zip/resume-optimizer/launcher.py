#!/usr/bin/env python3
"""
Resume Optimizer - Launcher
Inicia a aplicação completa (API + Frontend)
"""

import os
import sys
import subprocess
import time
import webbrowser
from pathlib import Path
from multiprocessing import Process

def start_api():
    """Inicia a API FastAPI"""
    api_path = Path(__file__).parent / "backend" / "main.py"
    subprocess.run([sys.executable, str(api_path)])

def start_frontend():
    """Inicia o frontend Streamlit"""
    frontend_path = Path(__file__).parent / "frontend" / "app.py"
    subprocess.run([
        sys.executable, "-m", "streamlit", "run", 
        str(frontend_path),
        "--server.port=8501",
        "--server.headless=true"
    ])

def check_dependencies():
    """Verifica se as dependências estão instaladas"""
    try:
        import fastapi
        import streamlit
        import openai
        print("✅ Dependências verificadas")
        return True
    except ImportError as e:
        print(f"❌ Dependência faltando: {e}")
        print("Instalando dependências...")
        req_file = Path(__file__).parent / "requirements.txt"
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(req_file)])
        return True

def main():
    print("="*60)
    print("🚀 RESUME OPTIMIZER PRO")
    print("Análise e Otimização de Currículos com IA")
    print("="*60)

    # Verificar dependências
    check_dependencies()

    # Verificar API Key
    if not os.getenv("OPENAI_API_KEY"):
        env_file = Path(__file__).parent / ".env"
        if env_file.exists():
            # Carregar .env
            with open(env_file) as f:
                for line in f:
                    if line.strip() and not line.startswith("#"):
                        key, value = line.strip().split("=", 1)
                        os.environ[key] = value

    print("\n📡 Iniciando serviços...")
    print("   API: http://localhost:8000")
    print("   App: http://localhost:8501")
    print("\n⏳ Aguarde...")

    # Iniciar API em processo separado
    api_process = Process(target=start_api)
    api_process.start()

    # Aguardar API iniciar
    time.sleep(3)

    # Iniciar Frontend
    try:
        start_frontend()
    except KeyboardInterrupt:
        print("\n\n🛑 Encerrando serviços...")
        api_process.terminate()
        print("✅ Programa encerrado")

if __name__ == "__main__":
    main()
