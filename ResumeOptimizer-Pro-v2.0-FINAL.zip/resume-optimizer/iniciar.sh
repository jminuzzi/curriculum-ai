#!/bin/bash
echo "============================================"
echo "   RESUME OPTIMIZER PRO v1.0"
echo "============================================"

if ! command -v python3 &> /dev/null; then
    echo "[ERRO] Python 3 não encontrado!"
    exit 1
fi

echo "[INFO] Iniciando Resume Optimizer..."
echo "[INFO] Acesse http://localhost:8501 no navegador"
echo ""
python3 ResumeOptimizer.py
