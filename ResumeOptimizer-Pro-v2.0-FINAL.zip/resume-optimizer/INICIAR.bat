@echo off
echo ============================================
echo    RESUME OPTIMIZER PRO v1.0
echo ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado!
    echo Por favor, instale o Python 3.8+ em python.org
    pause
    exit /b 1
)

echo [INFO] Iniciando Resume Optimizer...
echo [INFO] Acesse http://localhost:8501 no navegador
echo.
python ResumeOptimizer.py
