from setuptools import setup, find_packages

setup(
    name="resume-optimizer-pro",
    version="2.0.0",
    description="Sistema de análise e otimização de currículos com IA",
    author="Jefferson Anderson Minuzzi",
    packages=find_packages(),
    install_requires=[
        "fastapi>=0.109.0",
        "uvicorn[standard]>=0.27.0",
        "openai>=1.10.0",
        "pdfplumber>=0.10.0",
        "playwright>=1.41.0",
        "reportlab>=4.0.9",
        "pytesseract>=0.3.10",
        "Pillow>=10.2.0",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "resume-optimizer=frontend.app:main",
        ],
    },
)
