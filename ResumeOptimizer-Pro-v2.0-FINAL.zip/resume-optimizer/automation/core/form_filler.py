
"""
Sistema Inteligente de Preenchimento de Formulários
Mapeia campos automaticamente e preenche com dados do CV
"""

import re
import logging
from typing import Dict, List, Optional, Any
from difflib import SequenceMatcher
from playwright.async_api import Page

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SmartFormFiller:
    """
    Preenche formulários de vagas automaticamente
    Usa matching fuzzy e IA para identificar campos
    """

    # Mapeamento de campos comuns
    FIELD_MAPPINGS = {
        # Dados pessoais
        'nome_completo': ['nome', 'name', 'full_name', 'nome_completo', 'first_name', 'last_name'],
        'email': ['email', 'e-mail', 'mail', 'correio'],
        'telefone': ['phone', 'telefone', 'celular', 'mobile', 'whatsapp', 'fone'],
        'endereco': ['address', 'endereco', 'endereço', 'location', 'cidade'],
        'linkedin': ['linkedin', 'linked-in', 'perfil_linkedin'],
        'portfolio': ['portfolio', 'website', 'site', 'github', 'gitlab'],

        # Documentos
        'cpf': ['cpf', 'documento'],
        'rg': ['rg', 'identidade'],
        'pretensao_salarial': ['salary', 'pretensao', 'expectativa', 'remuneracao', 'salario'],

        # Experiência
        'empresa_atual': ['current_company', 'empresa_atual'],
        'cargo_atual': ['current_job', 'cargo_atual', 'job_title'],
        'anos_experiencia': ['experience_years', 'anos_experiencia'],

        # Educação
        'formacao': ['education', 'formacao', 'formação', 'graduacao'],
        'instituicao': ['institution', 'university', 'universidade', 'faculdade'],

        # Outros
        'disponibilidade': ['availability', 'disponibilidade'],
        'deficiencia': ['disability', 'deficiencia', 'pcd'],
        'genero': ['gender', 'genero', 'sexo'],
        'etnia': ['ethnicity', 'raca', 'cor'],
    }

    def __init__(self, cv_data: Dict):
        self.cv_data = cv_data
        self.field_cache = {}  # Cache de campos identificados

    async def fill_form(self, page: Page, form_selector: Optional[str] = None) -> Dict[str, bool]:
        """
        Preenche formulário automaticamente
        Retorna dicionário com status de cada campo
        """
        results = {}

        # Detectar todos os campos de input
        inputs = await self._detect_form_fields(page, form_selector)
        logger.info(f"Detectados {len(inputs)} campos no formulário")

        for field_info in inputs:
            field_id = field_info.get('id', '')
            field_name = field_info.get('name', '')
            field_type = field_info.get('type', 'text')
            field_placeholder = field_info.get('placeholder', '')

            # Identificar tipo de campo
            field_key = self._identify_field_type(
                field_id, field_name, field_placeholder, field_info.get('label', '')
            )

            if field_key and field_key in self.cv_data:
                value = self.cv_data[field_key]
                success = await self._fill_field(page, field_info, value, field_type)
                results[field_key] = success

                if success:
                    logger.info(f"✓ Preencheu: {field_key}")
                else:
                    logger.warning(f"✗ Falhou: {field_key}")

        return results

    async def _detect_form_fields(self, page: Page, form_selector: Optional[str] = None) -> List[Dict]:
        """Detecta todos os campos de formulário na página"""

        selector = form_selector or 'body'

        # Script JavaScript para extrair informações dos campos
        script = """
        (elements) => {
            return elements.map(el => ({
                id: el.id,
                name: el.name,
                type: el.type || 'text',
                placeholder: el.placeholder,
                required: el.required,
                tagName: el.tagName,
                className: el.className,
                label: el.labels && el.labels[0] ? el.labels[0].textContent : '',
                selector: el.tagName.toLowerCase() + 
                         (el.id ? '#' + el.id : '') + 
                         (el.name ? '[name="' + el.name + '"]' : '')
            }));
        }
        """

        fields = await page.eval_on_selector_all(
            f'{selector} input, {selector} textarea, {selector} select',
            script
        )

        return fields

    def _identify_field_type(self, field_id: str, field_name: str, placeholder: str, label: str) -> Optional[str]:
        """Identifica o tipo de campo usando matching fuzzy"""

        # Combinar todos os textos do campo
        field_texts = [field_id, field_name, placeholder, label]
        field_combined = ' '.join(filter(None, field_texts)).lower()

        best_match = None
        best_score = 0

        for key, variations in self.FIELD_MAPPINGS.items():
            for variation in variations:
                # Matching exato
                if variation in field_combined:
                    return key

                # Similaridade fuzzy
                for text in field_texts:
                    if text:
                        score = SequenceMatcher(None, variation, text.lower()).ratio()
                        if score > 0.8 and score > best_score:
                            best_score = score
                            best_match = key

        return best_match

    async def _fill_field(self, page: Page, field_info: Dict, value: Any, field_type: str) -> bool:
        """Preenche um campo específico baseado no tipo"""

        selector = field_info.get('selector', '')
        if not selector:
            return False

        try:
            if field_type in ['text', 'email', 'tel', 'url', 'password']:
                await page.fill(selector, str(value))

            elif field_type == 'textarea':
                await page.fill(selector, str(value))

            elif field_type == 'select-one':
                await page.select_option(selector, label=str(value))

            elif field_type == 'checkbox':
                if value:
                    await page.check(selector)
                else:
                    await page.uncheck(selector)

            elif field_type == 'radio':
                await page.check(selector)

            elif field_type == 'file':
                # Upload de arquivo - requer path
                if isinstance(value, str) and value:
                    await page.set_input_files(selector, value)

            elif field_type == 'date':
                # Formatar data
                await page.fill(selector, str(value))

            # Delay humano
            await page.wait_for_timeout(300)
            return True

        except Exception as e:
            logger.error(f"Erro ao preencher campo {selector}: {e}")
            return False

    async def upload_cv(self, page: Page, cv_path: str, selector: Optional[str] = None) -> bool:
        """Faz upload do currículo"""

        # Tentar encontrar input de arquivo
        if not selector:
            selectors = [
                'input[type="file"][accept*=".pdf"]',
                'input[type="file"][name*="cv" i]',
                'input[type="file"][name*="resume" i]',
                'input[type="file"][id*="curriculo" i]',
                'input[type="file"]'
            ]

            for sel in selectors:
                try:
                    await page.wait_for_selector(sel, timeout=2000)
                    selector = sel
                    break
                except:
                    continue

        if not selector:
            logger.error("Input de arquivo não encontrado")
            return False

        try:
            await page.set_input_files(selector, cv_path)
            logger.info(f"CV enviado: {cv_path}")
            return True
        except Exception as e:
            logger.error(f"Erro no upload: {e}")
            return False

    async def handle_dynamic_questions(self, page: Page) -> bool:
        """Tenta responder perguntas dinâmicas baseadas no CV"""

        # Procurar por perguntas comuns
        questions = await page.query_selector_all('label, .question, .field-label')

        for question in questions:
            text = await question.text_content()
            if not text:
                continue

            text_lower = text.lower()

            # Mapeamento de perguntas comuns
            if 'salário' in text_lower or 'pretensão' in text_lower:
                # Buscar valor no CV ou usar padrão
                value = self.cv_data.get('pretensao_salarial', 'A combinar')
                input_selector = await self._find_related_input(question)
                if input_selector:
                    await page.fill(input_selector, str(value))

            elif 'disponibilidade' in text_lower:
                value = self.cv_data.get('disponibilidade', 'Imediata')
                input_selector = await self._find_related_input(question)
                if input_selector:
                    await page.fill(input_selector, str(value))

        return True

    async def _find_related_input(self, label_element) -> Optional[str]:
        """Encontra input relacionado a um label"""
        # Tentar via 'for' attribute
        for_attr = await label_element.get_attribute('for')
        if for_attr:
            return f'#{for_attr}'

        # Tentar via parent
        parent = await label_element.query_selector('..')
        if parent:
            input_el = await parent.query_selector('input, select, textarea')
            if input_el:
                input_id = await input_el.get_attribute('id')
                if input_id:
                    return f'#{input_id}'

        return None

    def update_cv_data(self, new_data: Dict):
        """Atualiza dados do CV"""
        self.cv_data.update(new_data)


# Helper para extrair dados estruturados do CV
def extract_form_data(cv_data: Dict) -> Dict:
    """Extrai dados do CV no formato adequado para formulários"""

    form_data = {
        'nome_completo': cv_data.get('nome', ''),
        'email': cv_data.get('email', ''),
        'telefone': cv_data.get('telefone', ''),
        'linkedin': cv_data.get('linkedin', ''),
        'endereco': cv_data.get('endereco', ''),
    }

    # Extrair experiência atual
    experiencias = cv_data.get('experiencias', [])
    if experiencias:
        atual = experiencias[0]
        form_data['cargo_atual'] = atual.get('cargo', '')
        form_data['empresa_atual'] = atual.get('empresa', '')

    # Extrair formação
    educacao = cv_data.get('educacao', [])
    if educacao:
        formacao = educacao[0]
        form_data['formacao'] = formacao.get('curso', '')
        form_data['instituicao'] = formacao.get('instituicao', '')

    return form_data
