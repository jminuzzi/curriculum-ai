"""
Gerenciador de Browser para Automação de Sites de Emprego
Configurações anti-detecção e stealth
"""

import asyncio
from playwright.async_api import async_playwright, Page, Browser, BrowserContext
from typing import Optional, Dict, Any
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class StealthBrowserManager:
    """
    Gerenciador de browser com configurações anti-detecção
    """

    def __init__(self, headless: bool = False):
        self.headless = headless
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None
        self.playwright = None

    async def start(self, user_data_dir: Optional[str] = None) -> Page:
        """Inicia browser com stealth mode"""
        self.playwright = await async_playwright().start()

        # Configurações de stealth
        browser_args = [
            '--disable-blink-features=AutomationControlled',
            '--disable-web-security',
            '--disable-features=IsolateOrigins,site-per-process',
        ]

        if self.headless:
            browser_args.append('--headless=new')

        # Launch browser
        self.browser = await self.playwright.chromium.launch(
            headless=self.headless,
            args=browser_args
        )

        # Contexto com configurações human-like
        context_options = {
            'viewport': {'width': 1920, 'height': 1080},
            'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'locale': 'pt-BR',
            'timezone_id': 'America/Sao_Paulo',
            'permissions': ['geolocation'],
            'color_scheme': 'light',
        }

        if user_data_dir:
            context_options['storage_state'] = user_data_dir

        self.context = await self.browser.new_context(**context_options)

        # Scripts anti-detecção
        await self.context.add_init_script("""
            // Remove webdriver flag
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });

            // Mock plugins
            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5]
            });

            // Mock languages
            Object.defineProperty(navigator, 'languages', {
                get: () => ['pt-BR', 'pt', 'en-US', 'en']
            });

            // Hide automation
            window.chrome = { runtime: {} };

            // Pass Chrome Test
            const originalQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (parameters) => (
                parameters.name === 'notifications' ?
                    Promise.resolve({ state: Notification.permission }) :
                    originalQuery(parameters)
            );
        """)

        self.page = await self.context.new_page()

        # Configurar timeout padrão
        self.page.set_default_timeout(30000)

        logger.info("Browser iniciado em modo stealth")
        return self.page

    async def close(self):
        """Fecha browser e libera recursos"""
        if self.context:
            await self.context.close()
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
        logger.info("Browser fechado")

    async def safe_click(self, selector: str, timeout: int = 5000):
        """Clique seguro com espera por elemento"""
        try:
            await self.page.wait_for_selector(selector, timeout=timeout)
            await self.page.click(selector)
            await asyncio.sleep(0.5)  # Delay humano
            return True
        except Exception as e:
            logger.error(f"Erro ao clicar em {selector}: {e}")
            return False

    async def safe_fill(self, selector: str, value: str, clear_first: bool = True):
        """Preenchimento seguro com simulação de digitação"""
        try:
            await self.page.wait_for_selector(selector, timeout=5000)

            if clear_first:
                await self.page.fill(selector, '')

            # Simular digitação humana
            await self.page.type(selector, value, delay=50)
            await asyncio.sleep(0.3)
            return True
        except Exception as e:
            logger.error(f"Erro ao preencher {selector}: {e}")
            return False

    async def handle_login_popup(self, email: str, password: str, selectors: Dict[str, str]):
        """Manipula popup de login genérico"""
        try:
            # Aguardar popup
            popup = await self.page.wait_for_event('popup', timeout=10000)

            # Preencher credenciais
            await popup.fill(selectors.get('email', '#email'), email)
            await popup.fill(selectors.get('password', '#password'), password)

            # Clicar em login
            await popup.click(selectors.get('submit', 'button[type="submit"]'))

            # Aguardar redirect
            await popup.wait_for_load_state('networkidle')

            logger.info("Login realizado com sucesso")
            return True
        except Exception as e:
            logger.error(f"Erro no login: {e}")
            return False
