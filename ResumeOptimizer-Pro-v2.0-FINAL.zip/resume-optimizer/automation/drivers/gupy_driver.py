"""
Driver completo de automação para Gupy
Preenche formulários automaticamente com stealth
"""

import asyncio
import logging
from typing import Dict, Optional
from playwright.async_api import Page, expect

from ..core.browser_manager import StealthBrowserManager
from ..core.form_filler import SmartFormFiller, extract_form_data

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class GupyDriver:
    """
    Automação completa para portal.gupy.io
    """

    BASE_URL = "https://portal.gupy.io"

    def __init__(self, cv_data: Dict, headless: bool = False):
        self.cv_data = cv_data
        self.form_data = extract_form_data(cv_data)
        self.browser = StealthBrowserManager(headless=headless)
        self.form_filler = SmartFormFiller(self.form_data)
        self.page: Optional[Page] = None
        self.application_status = {}

    async def apply_to_job(self, job_url: str, cv_path: str, auto_submit: bool = False) -> Dict:
        """
        Realiza candidatura completa em uma vaga do Gupy

        Args:
            job_url: URL da vaga
            cv_path: Caminho do arquivo PDF do currículo
            auto_submit: Se True, envia automaticamente. Se False, aguarda confirmação
        """
        try:
            logger.info(f"🚀 Iniciando candidatura Gupy: {job_url}")

            # Iniciar browser
            self.page = await self.browser.start()

            # Navegar para vaga
            await self.page.goto(job_url, wait_until="networkidle")
            await asyncio.sleep(2)

            # Capturar título da vaga
            try:
                title_elem = await self.page.query_selector('h1, .job-title, [data-testid="job-title"]')
                job_title = await title_elem.text_content() if title_elem else "Vaga"
                self.application_status['vaga'] = job_title.strip()
            except:
                self.application_status['vaga'] = "Vaga"

            # Verificar login
            if await self._check_login_required():
                await self._handle_manual_login()

            # Clicar em candidatar-se
            apply_selectors = [
                'button:has-text("Candidatar-se")',
                'a:has-text("Candidatar-se")',
                '[data-testid="apply-button"]',
                'button:has-text("Candidate-se")',
                '.apply-button'
            ]

            for selector in apply_selectors:
                try:
                    btn = await self.page.query_selector(selector)
                    if btn:
                        await btn.click()
                        await asyncio.sleep(2)
                        break
                except:
                    continue

            # Preencher formulário multi-etapas
            step = 0
            max_steps = 15

            while step < max_steps:
                step += 1
                logger.info(f"📋 Preenchendo etapa {step}...")

                # Preencher campos visíveis
                filled = await self.form_filler.fill_form(self.page)
                self.application_status[f'etapa_{step}'] = filled

                # Upload CV se houver campo
                await self._handle_cv_upload(cv_path)

                # Verificar perguntas adicionais
                await self._handle_additional_questions()

                # Tentar avançar
                next_btn = await self._find_next_button()

                if next_btn:
                    is_enabled = await next_btn.is_enabled()
                    if is_enabled:
                        await next_btn.click()
                        await asyncio.sleep(2)

                        # Verificar se mudou de página ou se é submit final
                        current_url = self.page.url
                        if 'confirm' in current_url or 'review' in current_url:
                            break
                    else:
                        # Preencher campos obrigatórios faltantes
                        await self._fill_required_fields()
                else:
                    # Verificar se é página final
                    submit_btn = await self._find_submit_button()
                    if submit_btn:
                        break
                    else:
                        break

            # Revisão final
            await self._review_application()

            # Submeter ou aguardar confirmação
            if auto_submit:
                success = await self._submit_application()
                self.application_status['status'] = 'enviada' if success else 'falha'
            else:
                logger.info("⏸️ Aguardando confirmação manual para envio")
                self.application_status['status'] = 'aguardando_confirmacao'
                input("\n🛑 Revise a candidatura no navegador e pressione ENTER para enviar...")
                success = await self._submit_application()
                self.application_status['status'] = 'enviada' if success else 'falha'

            return self.application_status

        except Exception as e:
            logger.error(f"❌ Erro na candidatura: {e}")
            self.application_status['status'] = 'erro'
            self.application_status['erro'] = str(e)
            return self.application_status
        finally:
            await asyncio.sleep(3)  # Aguardar para ver resultado
            await self.browser.close()

    async def _check_login_required(self) -> bool:
        """Verifica se precisa de login"""
        indicators = [
            'text=Entrar',
            'text=Login',
            'input[type="password"]',
            '.login-form',
            '[data-testid="login-button"]'
        ]
        for indicator in indicators:
            if await self.page.query_selector(indicator):
                return True
        return False

    async def _handle_manual_login(self):
        """Aguarda login manual do usuário"""
        print("\n" + "="*60)
        print("🔐 LOGIN NO GUPY NECESSÁRIO")
        print("="*60)
        print("1. Faça login no navegador que abriu")
        print("2. Autorize o acesso se solicitado")
        print("3. Volte aqui e pressione ENTER")
        print("="*60 + "\n")
        input("Pressione ENTER após fazer login...")
        await asyncio.sleep(3)
        logger.info("✅ Continuando após login")

    async def _handle_cv_upload(self, cv_path: str):
        """Faz upload do currículo"""
        try:
            # Procurar input de arquivo
            file_input = await self.page.query_selector(
                'input[type="file"][accept*=".pdf"], input[type="file"][name*="resume"], input[type="file"][name*="cv"]'
            )

            if file_input:
                await file_input.set_input_files(cv_path)
                logger.info(f"✅ CV enviado: {cv_path}")
                await asyncio.sleep(1)
        except Exception as e:
            logger.warning(f"⚠️ Upload automático falhou: {e}")

    async def _handle_additional_questions(self):
        """Responde perguntas adicionais comuns"""
        questions = await self.page.query_selector_all('label, .question, .field-label')

        for question in questions:
            try:
                text = await question.text_content()
                if not text:
                    continue

                text_lower = text.lower()

                # Mapeamento de perguntas comuns
                if any(word in text_lower for word in ['salário', 'pretensão', 'remuneração']):
                    value = self.form_data.get('pretensao_salarial', 'A combinar')
                    await self._fill_question_input(question, value)

                elif any(word in text_lower for word in ['disponibilidade', 'quando']):
                    await self._fill_question_input(question, 'Imediata')

                elif any(word in text_lower for word in ['deficiência', 'pcd', 'deficiente']):
                    # Não marcar nada, deixar para usuário
                    pass

                elif 'linkedin' in text_lower:
                    await self._fill_question_input(question, self.form_data.get('linkedin', ''))

            except Exception as e:
                logger.debug(f"Erro ao processar pergunta: {e}")

    async def _fill_question_input(self, question_element, value: str):
        """Preenche input relacionado a uma pergunta"""
        try:
            # Tentar encontrar input relacionado
            for_attr = await question_element.get_attribute('for')
            if for_attr:
                input_sel = f'#{for_attr}'
                await self.page.fill(input_sel, str(value))
                return

            # Procurar input próximo
            parent = await question_element.query_selector('xpath=..')
            if parent:
                input_el = await parent.query_selector('input, select, textarea')
                if input_el:
                    await input_el.fill(str(value))
        except:
            pass

    async def _fill_required_fields(self):
        """Preenche campos obrigatórios não preenchidos"""
        required = await self.page.query_selector_all('[required]:placeholder-shown, [required]:not([value])')

        for field in required:
            try:
                field_type = await field.get_attribute('type')
                name = await field.get_attribute('name') or ''

                if 'nome' in name.lower():
                    await field.fill(self.form_data.get('nome_completo', 'Não informado'))
                elif 'email' in name.lower():
                    await field.fill(self.form_data.get('email', 'email@exemplo.com'))
                elif 'telefone' in name.lower():
                    await field.fill(self.form_data.get('telefone', '(00) 00000-0000'))
                else:
                    await field.fill('Não informado')

            except:
                pass

    async def _find_next_button(self):
        """Encontra botão de próxima etapa"""
        selectors = [
            'button:has-text("Próximo")',
            'button:has-text("Continuar")',
            'button:has-text("Avançar")',
            'button[type="submit"]:not(:has-text("Enviar"))',
            '[data-testid="next-button"]'
        ]

        for selector in selectors:
            btn = await self.page.query_selector(selector)
            if btn:
                return btn
        return None

    async def _find_submit_button(self):
        """Encontra botão de envio final"""
        selectors = [
            'button:has-text("Enviar candidatura")',
            'button:has-text("Finalizar")',
            'button:has-text("Confirmar")',
            'button[type="submit"]:has-text("Enviar")',
            '[data-testid="submit-application"]'
        ]

        for selector in selectors:
            btn = await self.page.query_selector(selector)
            if btn:
                return btn
        return None

    async def _review_application(self):
        """Tela de revisão antes do envio"""
        logger.info("🔍 Etapa de revisão")
        # Tirar screenshot para log
        try:
            await self.page.screenshot(path=f"gupy_review_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
        except:
            pass

    async def _submit_application(self) -> bool:
        """Envia candidatura final"""
        try:
            submit_btn = await self._find_submit_button()
            if submit_btn:
                # Verificar termos
                terms = await self.page.query_selector('input[type="checkbox"][name*="termo"], input[type="checkbox"][name*="consent"]')
                if terms:
                    await terms.check()

                await submit_btn.click()
                await asyncio.sleep(3)

                # Verificar sucesso
                success_indicators = [
                    'text=Candidatura enviada',
                    'text=Sucesso',
                    '.success-message',
                    '[data-testid="success-message"]'
                ]

                for indicator in success_indicators:
                    if await self.page.query_selector(indicator):
                        logger.info("✅ Candidatura enviada com sucesso!")
                        return True

                return True
            return False
        except Exception as e:
            logger.error(f"Erro ao enviar: {e}")
            return False


# Função de conveniência
async def apply_gupy(job_url: str, cv_path: str, cv_data: Dict, headless: bool = False):
    """Função simples para candidatura no Gupy"""
    driver = GupyDriver(cv_data, headless=headless)
    return await driver.apply_to_job(job_url, cv_path)
