"""
Driver completo de automação para Catho
"""

import asyncio
import logging
from typing import Dict
from playwright.async_api import Page

from ..core.browser_manager import StealthBrowserManager
from ..core.form_filler import SmartFormFiller, extract_form_data

logger = logging.getLogger(__name__)


class CathoDriver:
    """
    Automação para Catho.com.br
    """

    BASE_URL = "https://www.catho.com.br"

    def __init__(self, cv_data: Dict, headless: bool = False):
        self.cv_data = cv_data
        self.form_data = extract_form_data(cv_data)
        self.browser = StealthBrowserManager(headless=headless)
        self.form_filler = SmartFormFiller(self.form_data)
        self.page: Page = None
        self.status = {}

    async def apply_to_job(self, job_url: str, cv_path: str) -> Dict:
        """Candidata-se a uma vaga na Catho"""
        try:
            logger.info(f"🚀 Iniciando candidatura Catho: {job_url}")

            self.page = await self.browser.start()
            await self.page.goto(job_url, wait_until="networkidle")
            await asyncio.sleep(2)

            # Capturar título
            try:
                title = await self.page.query_selector('h1')
                self.status['vaga'] = await title.text_content() if title else "Vaga"
            except:
                self.status['vaga'] = "Vaga"

            # Clicar em candidatar
            apply_btn = await self.page.query_selector(
                'a:has-text("Candidatar-se"), button:has-text("Candidatar")'
            )
            if apply_btn:
                await apply_btn.click()
                await asyncio.sleep(2)

            # Verificar se precisa de login
            if await self.page.query_selector('input[type="password"]'):
                print("\n🔐 Faça login na Catho e pressione ENTER...")
                input("Login realizado? ")
                await asyncio.sleep(2)

            # Preencher formulário
            await self.form_filler.fill_form(self.page)
            await self.form_filler.upload_cv(self.page, cv_path)

            # Confirmar
            submit = await self.page.query_selector(
                'button:has-text("Enviar"), button[type="submit"]'
            )
            if submit:
                await submit.click()
                await asyncio.sleep(3)
                self.status['status'] = 'enviada'
            else:
                self.status['status'] = 'aguardando_confirmacao'

            return self.status

        except Exception as e:
            logger.error(f"Erro Catho: {e}")
            self.status['status'] = 'erro'
            self.status['erro'] = str(e)
            return self.status
        finally:
            await asyncio.sleep(2)
            await self.browser.close()


async def apply_catho(job_url: str, cv_path: str, cv_data: Dict, headless: bool = False):
    """Função simples para candidatura na Catho"""
    driver = CathoDriver(cv_data, headless=headless)
    return await driver.apply_to_job(job_url, cv_path)
