@echo off
echo ============================================
echo    Resume Optimizer Pro v2.0
echo ============================================
echo.

REM Verificar Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado!
    echo Por favor, instale o Python 3.8+ em https://python.org
    pause
    exit /b 1
)

REM Executar launcher
python "%~dp0launcher.py"
