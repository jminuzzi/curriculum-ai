"""
Resume Optimizer API
API principal para análise e otimização de currículos
"""

import os
import json
import asyncio
from typing import Optional, List
from contextlib import asynccontextmanager

from fastapi import FastAPI, File, UploadFile, Form, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

from api.services.pdf_extractor import PDFExtractor, extract_cv
from api.services.ai_analyzer import CVAnalyzer, analyze_cv
from api.services.cv_optimizer import CVOptimizer, optimize_cv

# Models Pydantic
class AnalysisRequest(BaseModel):
    cv_text: str
    target_role: Optional[str] = None
    job_description: Optional[str] = None

class OptimizationRequest(BaseModel):
    cv_data: dict
    analysis: dict
    target_role: Optional[str] = None
    job_description: Optional[str] = None

class JobApplicationRequest(BaseModel):
    job_url: str
    platform: str  # gupy, catho, linkedin
    cv_path: str
    user_data: dict

# App
app = FastAPI(
    title="Resume Optimizer API",
    description="API para análise, otimização e automação de currículos",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Estado global
extractor = PDFExtractor()
analyzer = CVAnalyzer()
optimizer = CVOptimizer()

@app.get("/")
async def root():
    return {"message": "Resume Optimizer API", "version": "1.0.0"}

@app.post("/api/extract")
async def extract_resume(file: UploadFile = File(...)):
    """Extrai texto e dados estruturados de um currículo PDF/DOCX"""
    try:
        # Salvar arquivo temporariamente
        temp_path = f"data/uploads/{file.filename}"
        os.makedirs("data/uploads", exist_ok=True)

        with open(temp_path, "wb") as f:
            content = await file.read()
            f.write(content)

        # Extrair
        result = extract_cv(temp_path)

        # Limpar arquivo
        os.remove(temp_path)

        return {
            "success": True,
            "data": result
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/analyze")
async def analyze_resume(request: AnalysisRequest):
    """Analisa currículo com IA"""
    try:
        result = await analyze_cv(
            request.cv_text,
            target_role=request.target_role,
            job_description=request.job_description
        )
        return {
            "success": True,
            "analysis": result
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/optimize")
async def optimize_resume(request: OptimizationRequest):
    """Otimiza currículo baseado na análise"""
    try:
        result = await optimize_cv(
            request.cv_data,
            request.analysis,
            target_role=request.target_role,
            job_description=request.job_description
        )
        return {
            "success": True,
            "optimized": result
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/full-process")
async def full_process(
    file: UploadFile = File(...),
    target_role: Optional[str] = Form(None),
    job_description: Optional[str] = Form(None)
):
    """Processo completo: Extração -> Análise -> Otimização"""
    try:
        # 1. Extrair
        temp_path = f"data/uploads/{file.filename}"
        os.makedirs("data/uploads", exist_ok=True)

        with open(temp_path, "wb") as f:
            content = await file.read()
            f.write(content)

        cv_data = extract_cv(temp_path)

        # 2. Analisar
        analysis = await analyze_cv(
            cv_data["raw_text"],
            target_role=target_role,
            job_description=job_description
        )

        # 3. Otimizar
        optimized = await optimize_cv(
            cv_data,
            analysis,
            target_role=target_role,
            job_description=job_description
        )

        # Limpar
        os.remove(temp_path)

        return {
            "success": True,
            "extraction": cv_data,
            "analysis": analysis,
            "optimized": optimized
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/apply")
async def apply_to_job(request: JobApplicationRequest, background_tasks: BackgroundTasks):
    """Inicia candidatura em site de emprego (executa em background)"""
    try:
        # Executar automação em background
        background_tasks.add_task(
            run_job_application,
            request.platform,
            request.job_url,
            request.cv_path,
            request.user_data
        )

        return {
            "success": True,
            "message": f"Candidatura iniciada em {request.platform}",
            "job_url": request.job_url
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

async def run_job_application(platform: str, job_url: str, cv_path: str, user_data: dict):
    """Executa candidatura de forma assíncrona"""
    if platform == "gupy":
        from automation.drivers.gupy_driver import GupyDriver
        driver = GupyDriver(user_data)
        await driver.apply_to_job(job_url, cv_path)
    elif platform == "catho":
        from automation.drivers.catho_driver import CathoDriver
        driver = CathoDriver(user_data)
        await driver.apply_to_job(job_url, cv_path)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
