"""
Gerador de Carta de Apresentação (Cover Letter) com IA
Personalizada para cada vaga
"""

import json
from typing import Dict, Optional
from dataclasses import dataclass
from openai import AsyncOpenAI
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class CoverLetter:
    """Estrutura da carta de apresentação"""
    content: str
    subject_line: str
    tone: str
    highlights: list

    def to_dict(self):
        return {
            "content": self.content,
            "subject_line": self.subject_line,
            "tone": self.tone,
            "highlights": self.highlights
        }


class CoverLetterGenerator:
    """
    Gera cartas de apresentação personalizadas usando GPT-4
    """

    def __init__(self, api_key: str):
        self.client = AsyncOpenAI(api_key=api_key)

    async def generate(
        self,
        cv_data: Dict,
        job_description: str,
        company_name: str,
        recruiter_name: Optional[str] = None,
        tone: str = "professional",  # professional, enthusiastic, formal
        max_length: int = 400  # palavras
    ) -> CoverLetter:
        """
        Gera carta de apresentação personalizada

        Args:
            cv_data: Dados do currículo
            job_description: Descrição da vaga
            company_name: Nome da empresa
            recruiter_name: Nome do recrutador (opcional)
            tone: Tom da carta
            max_length: Tamanho máximo em palavras
        """

        system_prompt = """Você é um especialista em carreiras com 20 anos de experiência.
Escreva cartas de apresentação que:
1. Conectem experiências do candidato às necessidades da vaga
2. Demonstrem entusiasmo genuíno pela empresa
3. Destaquem conquistas mensuráveis relevantes
4. Tenham call-to-action claro
5. Sejam concisas e impactantes"""

        user_prompt = f"""Escreva uma carta de apresentação para:

CANDIDATO:
Nome: {cv_data.get('nome', '')}
Experiências: {json.dumps(cv_data.get('experiencias', [])[:2], ensure_ascii=False)}
Principais Skills: {', '.join(cv_data.get('habilidades', [])[:8])}

EMPRESA: {company_name}

VAGA:
{job_description[:1500]}

REQUISITOS:
- Tom: {tone}
- Tamanho: máximo {max_length} palavras
- Destacar: 2-3 conquistas mais relevantes para a vaga
- Estrutura: Saudação personalizada, 3 parágrafos, fechamento profissional

Retorne JSON:
{{
    "subject_line": "Assunto do email",
    "content": "Texto completo da carta com parágrafos",
    "tone": "tom utilizado",
    "highlights": ["ponto 1", "ponto 2", "ponto 3"]
}}"""

        try:
            response = await self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                response_format={"type": "json_object"},
                temperature=0.7
            )

            result = json.loads(response.choices[0].message.content)

            # Personalizar saudação se nome do recrutador fornecido
            content = result["content"]
            if recruiter_name:
                content = content.replace("Prezado(a) Recrutador(a),", f"Prezado(a) {recruiter_name},")
                content = content.replace("Caro(a) Recrutador(a),", f"Caro(a) {recruiter_name},")

            cover_letter = CoverLetter(
                content=content,
                subject_line=result["subject_line"],
                tone=result["tone"],
                highlights=result.get("highlights", [])
            )

            logger.info("✅ Cover letter gerada com sucesso")
            return cover_letter

        except Exception as e:
            logger.error(f"Erro ao gerar cover letter: {e}")
            raise

    async def generate_variations(
        self,
        cv_data: Dict,
        job_description: str,
        company_name: str,
        variations: list = ["professional", "enthusiastic", "concise"]
    ) -> Dict[str, CoverLetter]:
        """Gera múltiplas variações de tom"""
        results = {}

        for tone in variations:
            cover = await self.generate(
                cv_data=cv_data,
                job_description=job_description,
                company_name=company_name,
                tone=tone
            )
            results[tone] = cover

        return results


# Função de conveniência
async def generate_cover_letter(
    cv_data: Dict,
    job_description: str,
    company_name: str,
    api_key: str,
    **kwargs
) -> Dict:
    """Função simples para gerar cover letter"""
    generator = CoverLetterGenerator(api_key)
    letter = await generator.generate(cv_data, job_description, company_name, **kwargs)
    return letter.to_dict()
