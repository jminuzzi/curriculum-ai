"""
Sistema de Notificações
Monitora mudanças de status e envia alertas
"""

import json
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, asdict
from enum import Enum
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class NotificationType(Enum):
    STATUS_CHANGE = "status_change"
    FOLLOW_UP = "follow_up"
    INTERVIEW_REMINDER = "interview_reminder"
    NEW_JOB_MATCH = "new_job_match"
    WEEKLY_SUMMARY = "weekly_summary"


@dataclass
class Notification:
    id: str
    type: NotificationType
    title: str
    message: str
    data: Dict
    created_at: str
    read: bool = False
    action_required: bool = False
    action_url: str = ""

    def to_dict(self):
        return {
            "id": self.id,
            "type": self.type.value,
            "title": self.title,
            "message": self.message,
            "data": self.data,
            "created_at": self.created_at,
            "read": self.read,
            "action_required": self.action_required,
            "action_url": self.action_url
        }


class NotificationManager:
    """
    Gerencia notificações do sistema
    """

    def __init__(self, storage_path: str = "notifications.json"):
        self.storage_path = storage_path
        self.notifications: List[Notification] = []
        self.callbacks: List[Callable] = []
        self._load_notifications()

    def _load_notifications(self):
        """Carrega notificações do arquivo"""
        try:
            with open(self.storage_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for item in data:
                    notif = Notification(
                        id=item['id'],
                        type=NotificationType(item['type']),
                        title=item['title'],
                        message=item['message'],
                        data=item['data'],
                        created_at=item['created_at'],
                        read=item.get('read', False),
                        action_required=item.get('action_required', False),
                        action_url=item.get('action_url', '')
                    )
                    self.notifications.append(notif)
        except FileNotFoundError:
            pass

    def _save_notifications(self):
        """Salva notificações no arquivo"""
        with open(self.storage_path, 'w', encoding='utf-8') as f:
            json.dump([n.to_dict() for n in self.notifications], f, indent=2, ensure_ascii=False)

    def add_notification(self, notification: Notification):
        """Adiciona nova notificação"""
        self.notifications.insert(0, notification)
        self._save_notifications()

        # Chamar callbacks
        for callback in self.callbacks:
            try:
                callback(notification)
            except:
                pass

        logger.info(f"Notificação criada: {notification.title}")

    def create_status_change_notification(
        self,
        application_id: int,
        company: str,
        position: str,
        old_status: str,
        new_status: str
    ):
        """Cria notificação de mudança de status"""
        notif = Notification(
            id=f"status_{application_id}_{datetime.now().timestamp()}",
            type=NotificationType.STATUS_CHANGE,
            title=f"Status atualizado: {company}",
            message=f"Sua candidatura para {position} mudou de '{old_status}' para '{new_status}'",
            data={
                "application_id": application_id,
                "company": company,
                "position": position,
                "old_status": old_status,
                "new_status": new_status
            },
            created_at=datetime.now().isoformat(),
            action_required=new_status in ['interview', 'offer'],
            action_url=f"/applications/{application_id}"
        )
        self.add_notification(notif)

    def create_follow_up_notification(self, application_id: int, company: str, position: str):
        """Cria notificação de follow-up"""
        notif = Notification(
            id=f"followup_{application_id}_{datetime.now().timestamp()}",
            type=NotificationType.FOLLOW_UP,
            title=f"Hora do follow-up: {company}",
            message=f"Já se passaram 7 dias desde sua candidatura para {position}. Que tal enviar um follow-up?",
            data={
                "application_id": application_id,
                "company": company,
                "position": position
            },
            created_at=datetime.now().isoformat(),
            action_required=True,
            action_url=f"/applications/{application_id}"
        )
        self.add_notification(notif)

    def create_interview_reminder(
        self,
        application_id: int,
        company: str,
        position: str,
        interview_date: str
    ):
        """Cria lembrete de entrevista"""
        notif = Notification(
            id=f"interview_{application_id}_{datetime.now().timestamp()}",
            type=NotificationType.INTERVIEW_REMINDER,
            title=f"Entrevista amanhã: {company}",
            message=f"Não esqueça da sua entrevista para {position} às {interview_date}",
            data={
                "application_id": application_id,
                "company": company,
                "position": position,
                "interview_date": interview_date
            },
            created_at=datetime.now().isoformat(),
            action_required=True,
            action_url=f"/applications/{application_id}"
        )
        self.add_notification(notif)

    def create_job_match_notification(self, job_title: str, company: str, match_score: float):
        """Cria notificação de nova vaga compatível"""
        notif = Notification(
            id=f"match_{datetime.now().timestamp()}",
            type=NotificationType.NEW_JOB_MATCH,
            title=f"Nova vaga compatível: {match_score:.0%} match",
            message=f"Encontramos uma vaga de {job_title} na {company} que combina com seu perfil!",
            data={
                "job_title": job_title,
                "company": company,
                "match_score": match_score
            },
            created_at=datetime.now().isoformat(),
            action_required=True,
            action_url="/job_search"
        )
        self.add_notification(notif)

    def get_unread_notifications(self) -> List[Notification]:
        """Retorna notificações não lidas"""
        return [n for n in self.notifications if not n.read]

    def mark_as_read(self, notification_id: str):
        """Marca notificação como lida"""
        for n in self.notifications:
            if n.id == notification_id:
                n.read = True
                break
        self._save_notifications()

    def mark_all_as_read(self):
        """Marca todas como lidas"""
        for n in self.notifications:
            n.read = True
        self._save_notifications()

    def register_callback(self, callback: Callable):
        """Registra callback para novas notificações"""
        self.callbacks.append(callback)

    def get_notifications_by_type(self, notif_type: NotificationType) -> List[Notification]:
        """Filtra notificações por tipo"""
        return [n for n in self.notifications if n.type == notif_type]


class EmailNotifier:
    """
    Envia notificações por email
    """

    def __init__(self, smtp_server: str, smtp_port: int, username: str, password: str):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.username = username
        self.password = password

    def send_notification(self, to_email: str, notification: Notification):
        """Envia notificação por email"""
        try:
            msg = MIMEMultipart()
            msg['From'] = self.username
            msg['To'] = to_email
            msg['Subject'] = f"[Resume Optimizer] {notification.title}"

            body = f"""
{notification.message}

Data: {notification.created_at}

---
Enviado por Resume Optimizer Pro
"""

            msg.attach(MIMEText(body, 'plain'))

            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()
            server.login(self.username, self.password)
            server.send_message(msg)
            server.quit()

            logger.info(f"Email enviado para {to_email}")
            return True
        except Exception as e:
            logger.error(f"Erro ao enviar email: {e}")
            return False


class NotificationMonitor:
    """
    Monitora mudanças e gera notificações automaticamente
    """

    def __init__(self, tracker, notifier: NotificationManager):
        self.tracker = tracker
        self.notifier = notifier
        self.running = False

    async def start_monitoring(self, interval_minutes: int = 60):
        """Inicia monitoramento contínuo"""
        self.running = True
        logger.info(f"Monitoramento iniciado (intervalo: {interval_minutes}min)")

        while self.running:
            try:
                await self._check_follow_ups()
                await self._check_status_changes()
                await asyncio.sleep(interval_minutes * 60)
            except Exception as e:
                logger.error(f"Erro no monitoramento: {e}")
                await asyncio.sleep(60)

    async def _check_follow_ups(self):
        """Verifica candidaturas que precisam de follow-up"""
        apps = self.tracker.get_follow_ups_needed()
        for app in apps:
            self.notifier.create_follow_up_notification(
                app.id, app.company, app.position
            )

    async def _check_status_changes(self):
        """Verifica mudanças de status (simulação)"""
        # Aqui integraria com APIs dos sites ou web scraping
        pass

    def stop(self):
        """Para o monitoramento"""
        self.running = False


# UI para Streamlit
class NotificationUI:
    """Interface de notificações para Streamlit"""

    def __init__(self, manager: NotificationManager):
        self.manager = manager

    def render(self):
        """Renderiza interface de notificações"""
        import streamlit as st

        st.sidebar.markdown("---")
        st.sidebar.subheader("🔔 Notificações")

        unread = self.manager.get_unread_notifications()

        if unread:
            st.sidebar.warning(f"{len(unread)} não lidas")

            for notif in unread[:5]:
                with st.sidebar.expander(f"📌 {notif.title}"):
                    st.write(notif.message)
                    st.caption(f"{notif.created_at[:10]}")
                    if st.button("Marcar como lida", key=f"read_{notif.id}"):
                        self.manager.mark_as_read(notif.id)
                        st.rerun()
        else:
            st.sidebar.success("Tudo em ordem! ✓")


# Funções de conveniência
def create_notification_manager() -> NotificationManager:
    """Cria gerenciador de notificações"""
    return NotificationManager()
