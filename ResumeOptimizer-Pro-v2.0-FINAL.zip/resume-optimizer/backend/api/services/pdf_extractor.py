"""
Módulo de Extração de Texto de Currículos PDF
Suporta: PDF nativo, PDF escaneado (OCR), DOCX
"""

import pdfplumber
import pytesseract
from PIL import Image
import io
import re
import json
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from pathlib import Path
import docx2txt
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ExtractedCV:
    """Estrutura de dados do CV extraído"""
    raw_text: str
    nome: str = ""
    email: str = ""
    telefone: str = ""
    linkedin: str = ""
    endereco: str = ""
    resumo: str = ""
    experiencias: List[Dict] = None
    educacao: List[Dict] = None
    habilidades: List[str] = None
    certificacoes: List[str] = None
    idiomas: List[Dict] = None
    metadata: Dict = None

    def __post_init__(self):
        if self.experiencias is None:
            self.experiencias = []
        if self.educacao is None:
            self.educacao = []
        if self.habilidades is None:
            self.habilidades = []
        if self.certificacoes is None:
            self.certificacoes = []
        if self.idiomas is None:
            self.idiomas = []
        if self.metadata is None:
            self.metadata = {}

    def to_dict(self) -> Dict:
        return asdict(self)


class PDFExtractor:
    """Extrator inteligente de currículos com OCR fallback"""

    def __init__(self, tesseract_path: Optional[str] = None):
        if tesseract_path:
            pytesseract.pytesseract.tesseract_cmd = tesseract_path
        self.patterns = self._compile_patterns()

    def _compile_patterns(self) -> Dict[str, re.Pattern]:
        """Compila regex para extração de informações"""
        return {
            'email': re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
            'telefone': re.compile(r'(?:\+55\s?)?(?:\(?\d{2}\)?\s?)?(?:9\d{4}|\d{4})[-.\s]?\d{4}'),
            'linkedin': re.compile(r'(?:linkedin\.com/in/|linkedin:)([a-zA-Z0-9-]+)', re.IGNORECASE),
            'data': re.compile(r'(\d{1,2}/\d{1,2}/\d{2,4}|\d{1,2} de [a-z]+ de \d{4}|jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[\/\s-]*(\d{4}|atual|presente)', re.IGNORECASE),
        }

    def extract(self, file_path: str) -> ExtractedCV:
        """
        Extrai informações estruturadas de qualquer arquivo de currículo
        """
        path = Path(file_path)

        if not path.exists():
            raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")

        logger.info(f"Extraindo: {path.name}")

        # Detectar tipo de arquivo
        suffix = path.suffix.lower()

        if suffix == '.pdf':
            raw_text = self._extract_pdf(path)
        elif suffix in ['.docx', '.doc']:
            raw_text = self._extract_docx(path)
        elif suffix in ['.jpg', '.jpeg', '.png']:
            raw_text = self._extract_image(path)
        else:
            raise ValueError(f"Formato não suportado: {suffix}")

        # Estruturar dados
        cv_data = self._structure_data(raw_text)
        cv_data.metadata = {
            'original_file': path.name,
            'file_type': suffix,
            'extraction_method': 'pdfplumber' if suffix == '.pdf' else 'ocr' if suffix in ['.jpg', '.jpeg', '.png'] else 'docx2txt',
            'text_length': len(raw_text)
        }

        return cv_data

    def _extract_pdf(self, path: Path) -> str:
        """Extrai texto de PDF, com OCR fallback para imagens"""
        text_parts = []

        with pdfplumber.open(path) as pdf:
            for i, page in enumerate(pdf.pages):
                # Tentar extração nativa primeiro
                page_text = page.extract_text()

                if page_text and len(page_text.strip()) > 50:
                    text_parts.append(page_text)
                else:
                    # Fallback para OCR se página parece ser imagem
                    logger.info(f"Página {i+1} parece imagem, aplicando OCR...")
                    img = page.to_image(resolution=300).original
                    ocr_text = pytesseract.image_to_string(img, lang='por+eng')
                    text_parts.append(ocr_text)

        return "\n".join(text_parts)

    def _extract_docx(self, path: Path) -> str:
        """Extrai texto de arquivos Word"""
        return docx2txt.process(str(path))

    def _extract_image(self, path: Path) -> str:
        """Extrai texto de imagem usando OCR"""
        image = Image.open(path)
        return pytesseract.image_to_string(image, lang='por+eng')

    def _structure_data(self, text: str) -> ExtractedCV:
        """Estrutura o texto bruto em dados organizados"""
        cv = ExtractedCV(raw_text=text)

        # Extrair contato
        cv.email = self._extract_email(text)
        cv.telefone = self._extract_phone(text)
        cv.linkedin = self._extract_linkedin(text)
        cv.nome = self._extract_name(text)

        # Extrair seções
        cv.experiencias = self._extract_experience(text)
        cv.educacao = self._extract_education(text)
        cv.habilidades = self._extract_skills(text)
        cv.idiomas = self._extract_languages(text)
        cv.certificacoes = self._extract_certifications(text)
        cv.resumo = self._extract_summary(text)

        return cv

    def _extract_email(self, text: str) -> str:
        match = self.patterns['email'].search(text)
        return match.group(0) if match else ""

    def _extract_phone(self, text: str) -> str:
        matches = self.patterns['telefone'].findall(text)
        return matches[0] if matches else ""

    def _extract_linkedin(self, text: str) -> str:
        match = self.patterns['linkedin'].search(text)
        return f"linkedin.com/in/{match.group(1)}" if match else ""

    def _extract_name(self, text: str) -> str:
        """Heurística para extrair nome (primeira linha significativa)"""
        lines = [line.strip() for line in text.split('\n') if line.strip()]

        for line in lines[:5]:  # Verificar primeiras 5 linhas
            # Ignorar linhas que parecem email, telefone, ou títulos
            if (len(line) > 3 and 
                not self.patterns['email'].match(line) and
                not line.lower().startswith(('currículo', 'resume', 'cv', 'contato')) and
                not any(char.isdigit() for char in line)):
                return line.title()

        return ""

    def _extract_experience(self, text: str) -> List[Dict]:
        """Extrai experiências profissionais"""
        experiencias = []

        # Padrões comuns de seção de experiência
        section_patterns = [
            r'(?:EXPERIÊNCIA PROFISSIONAL|EXPERIÊNCIA|EXPERIENCE|HISTÓRICO PROFISSIONAL)(.*?)(?=\n(?:FORMAÇÃO|EDUCAÇÃO|HABILIDADES|CERTIFICAÇÕES|$))',
        ]

        exp_section = ""
        for pattern in section_patterns:
            match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
            if match:
                exp_section = match.group(1)
                break

        if not exp_section:
            return experiencias

        # Dividir por empresas/cargos (heurística básica)
        lines = exp_section.strip().split('\n')
        current_exp = {}

        for line in lines:
            line = line.strip()
            if not line:
                continue

            # Detectar datas (indicam novo cargo)
            if self.patterns['data'].search(line) or any(year in line for year in ['202', '201', '200']):
                if current_exp:
                    experiencias.append(current_exp)
                current_exp = {
                    'cargo': line,
                    'empresa': '',
                    'periodo': line,
                    'descricao': ''
                }
            elif current_exp:
                if not current_exp['empresa'] and len(line) < 50:
                    current_exp['empresa'] = line
                else:
                    current_exp['descricao'] += line + ' '

        if current_exp:
            experiencias.append(current_exp)

        return experiencias

    def _extract_education(self, text: str) -> List[Dict]:
        """Extrai formação acadêmica"""
        educacao = []

        section_patterns = [
            r'(?:FORMAÇÃO|EDUCAÇÃO|ACADÊMICO|EDUCATION|FORMAÇÃO ACADÊMICA)(.*?)(?=\n(?:EXPERIÊNCIA|HABILIDADES|CERTIFICAÇÕES|IDIOMAS|$))',
        ]

        edu_section = ""
        for pattern in section_patterns:
            match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
            if match:
                edu_section = match.group(1)
                break

        if edu_section:
            lines = [l.strip() for l in edu_section.split('\n') if l.strip()]
            for line in lines[:10]:  # Limitar para evitar poluição
                if any(word in line.lower() for word in ['bacharel', 'tecnólogo', 'mestrado', 'doutorado', 'mba', 'pós', 'graduação', 'universidade', 'faculdade']):
                    educacao.append({
                        'curso': line,
                        'instituicao': '',
                        'periodo': ''
                    })

        return educacao

    def _extract_skills(self, text: str) -> List[str]:
        """Extrai habilidades técnicas"""
        skills = []

        # Procurar seção de habilidades
        section_match = re.search(
            r'(?:HABILIDADES|SKILLS|COMPETÊNCIAS|CONHECIMENTOS TÉCNICOS)[:\s]*\n?(.*?)(?=\n(?:EXPERIÊNCIA|FORMAÇÃO|CERTIFICAÇÕES|IDIOMAS|PROJETOS|$))',
            text, re.DOTALL | re.IGNORECASE
        )

        if section_match:
            skills_text = section_match.group(1)
            # Separar por vírgulas, bullets ou quebras de linha
            skills = [s.strip() for s in re.split(r'[,;•\-\n]', skills_text) if s.strip() and len(s.strip()) > 1]

        # Também procurar por palavras-chave comuns de tecnologia
        tech_keywords = [
            'python', 'java', 'javascript', 'typescript', 'react', 'node', 'sql', 
            'aws', 'azure', 'docker', 'kubernetes', 'git', 'agile', 'scrum',
            'excel', 'powerpoint', 'word', 'power bi', 'tableau', 'sap',
            'liderança', 'gestão', 'projetos', 'negociação', 'comunicação'
        ]

        text_lower = text.lower()
        for keyword in tech_keywords:
            if keyword in text_lower and keyword not in [s.lower() for s in skills]:
                skills.append(keyword.title() if keyword[0].islower() else keyword)

        return list(set(skills))[:20]  # Limitar a 20 skills

    def _extract_languages(self, text: str) -> List[Dict]:
        """Extrai idiomas"""
        idiomas = []

        lang_patterns = [
            r'(?:Inglês|English)[\s:]*((?:Básico|Intermediário|Avançado|Fluente|Nativo|B1|B2|C1|C2|Basic|Intermediate|Advanced|Fluent|Native))',
            r'(?:Espanhol|Spanish)[\s:]*((?:Básico|Intermediário|Avançado|Fluente|Nativo|B1|B2|C1|C2))',
            r'(?:Português|Portuguese)[\s:]*((?:Nativo|Fluente))',
        ]

        for pattern in lang_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                lang_name = pattern.split('[')[0].replace('(?:', '').replace('|', '/')
                idiomas.append({
                    'idioma': lang_name,
                    'nivel': match.group(1).title()
                })

        return idiomas

    def _extract_certifications(self, text: str) -> List[str]:
        """Extrai certificações"""
        certs = []

        section_match = re.search(
            r'(?:CERTIFICAÇÕES|CERTIFICATIONS|CURSOS|COURSES)[:\s]*\n?(.*?)(?=\n(?:EXPERIÊNCIA|FORMAÇÃO|HABILIDADES|IDIOMAS|$))',
            text, re.DOTALL | re.IGNORECASE
        )

        if section_match:
            certs_text = section_match.group(1)
            certs = [c.strip() for c in certs_text.split('\n') if c.strip() and len(c.strip()) > 5]

        return certs[:10]

    def _extract_summary(self, text: str) -> str:
        """Extrai resumo/objetivo profissional"""
        patterns = [
            r'(?:RESUMO|OBJETIVO|PERFIL PROFISSIONAL|SUMMARY|OBJECTIVE)[:\s]*\n?(.*?)(?=\n(?:EXPERIÊNCIA|FORMAÇÃO|HABILIDADES|$))',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
            if match:
                return match.group(1).strip()[:500]  # Limitar tamanho

        return ""


# Função de conveniência
def extract_cv(file_path: str) -> Dict:
    """Função simples para extração de CV"""
    extractor = PDFExtractor()
    cv = extractor.extract(file_path)
    return cv.to_dict()


if __name__ == "__main__":
    # Teste
    import sys
    if len(sys.argv) > 1:
        result = extract_cv(sys.argv[1])
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print("Uso: python pdf_extractor.py <arquivo.pdf>")
