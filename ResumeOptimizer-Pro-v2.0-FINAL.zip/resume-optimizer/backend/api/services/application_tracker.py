
"""
Dashboard de Acompanhamento de Candidaturas
Gerencia e monitora status de aplicações em tempo real
"""

import json
import sqlite3
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class Application:
    """Representa uma candidatura"""
    id: int = None
    company: str = ""
    position: str = ""
    platform: str = ""  # gupy, catho, linkedin, etc
    job_url: str = ""
    cv_version: str = ""
    cover_letter: str = ""
    status: str = "applied"  # applied, screening, interview, offer, rejected, ghosted
    applied_date: str = ""
    last_update: str = ""
    notes: str = ""
    follow_up_date: str = ""
    salary_range: str = ""
    location: str = ""
    remote: bool = False

    def to_dict(self):
        return asdict(self)


class ApplicationTracker:
    """
    Sistema de tracking de candidaturas
    """

    def __init__(self, db_path: str = "applications.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """Inicializa banco de dados SQLite"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company TEXT NOT NULL,
                position TEXT NOT NULL,
                platform TEXT,
                job_url TEXT,
                cv_version TEXT,
                cover_letter TEXT,
                status TEXT DEFAULT 'applied',
                applied_date TEXT,
                last_update TEXT,
                notes TEXT,
                follow_up_date TEXT,
                salary_range TEXT,
                location TEXT,
                remote BOOLEAN DEFAULT 0
            )
        """)

        conn.commit()
        conn.close()
        logger.info("Banco de dados inicializado")

    def add_application(self, app: Application) -> int:
        """Adiciona nova candidatura"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        now = datetime.now().isoformat()
        app.applied_date = now
        app.last_update = now

        # Calcular data de follow-up (7 dias depois)
        follow_up = datetime.now() + timedelta(days=7)
        app.follow_up_date = follow_up.isoformat()

        cursor.execute("""
            INSERT INTO applications 
            (company, position, platform, job_url, cv_version, cover_letter, 
             status, applied_date, last_update, notes, follow_up_date, salary_range, location, remote)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            app.company, app.position, app.platform, app.job_url, app.cv_version,
            app.cover_letter, app.status, app.applied_date, app.last_update,
            app.notes, app.follow_up_date, app.salary_range, app.location, app.remote
        ))

        app_id = cursor.lastrowid
        conn.commit()
        conn.close()

        logger.info(f"Candidatura adicionada: {app.position} na {app.company}")
        return app_id

    def update_status(self, app_id: int, new_status: str, notes: str = ""):
        """Atualiza status de uma candidatura"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        now = datetime.now().isoformat()

        cursor.execute("""
            UPDATE applications 
            SET status = ?, last_update = ?, notes = ?
            WHERE id = ?
        """, (new_status, now, notes, app_id))

        conn.commit()
        conn.close()

        logger.info(f"Status atualizado: {app_id} -> {new_status}")

    def get_all_applications(self, status_filter: str = None) -> List[Application]:
        """Retorna todas as candidaturas"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        if status_filter:
            cursor.execute(
                "SELECT * FROM applications WHERE status = ? ORDER BY applied_date DESC",
                (status_filter,)
            )
        else:
            cursor.execute("SELECT * FROM applications ORDER BY applied_date DESC")

        rows = cursor.fetchall()
        conn.close()

        applications = []
        for row in rows:
            app = Application(
                id=row['id'],
                company=row['company'],
                position=row['position'],
                platform=row['platform'],
                job_url=row['job_url'],
                cv_version=row['cv_version'],
                cover_letter=row['cover_letter'],
                status=row['status'],
                applied_date=row['applied_date'],
                last_update=row['last_update'],
                notes=row['notes'],
                follow_up_date=row['follow_up_date'],
                salary_range=row['salary_range'],
                location=row['location'],
                remote=bool(row['remote'])
            )
            applications.append(app)

        return applications

    def get_statistics(self) -> Dict:
        """Retorna estatísticas das candidaturas"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        stats = {
            "total": 0,
            "by_status": {},
            "by_platform": {},
            "this_week": 0,
            "response_rate": 0.0,
            "interview_rate": 0.0
        }

        # Total
        cursor.execute("SELECT COUNT(*) FROM applications")
        stats["total"] = cursor.fetchone()[0]

        # Por status
        cursor.execute("SELECT status, COUNT(*) FROM applications GROUP BY status")
        for row in cursor.fetchall():
            stats["by_status"][row[0]] = row[1]

        # Por plataforma
        cursor.execute("SELECT platform, COUNT(*) FROM applications GROUP BY platform")
        for row in cursor.fetchall():
            stats["by_platform"][row[0]] = row[1]

        # Esta semana
        week_ago = (datetime.now() - timedelta(days=7)).isoformat()
        cursor.execute("SELECT COUNT(*) FROM applications WHERE applied_date > ?", (week_ago,))
        stats["this_week"] = cursor.fetchone()[0]

        # Taxas
        if stats["total"] > 0:
            responded = sum(v for k, v in stats["by_status"].items() if k != 'applied')
            stats["response_rate"] = (responded / stats["total"]) * 100

            interviews = sum(v for k, v in stats["by_status"].items() 
                           if k in ['interview', 'offer', 'hired'])
            stats["interview_rate"] = (interviews / stats["total"]) * 100

        conn.close()
        return stats

    def get_follow_ups_needed(self) -> List[Application]:
        """Retorna candidaturas que precisam de follow-up"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        now = datetime.now().isoformat()

        cursor.execute("""
            SELECT * FROM applications 
            WHERE follow_up_date < ? AND status IN ('applied', 'screening')
            ORDER BY follow_up_date
        """, (now,))

        rows = cursor.fetchall()
        conn.close()

        applications = []
        for row in rows:
            app = Application(
                id=row['id'],
                company=row['company'],
                position=row['position'],
                status=row['status'],
                applied_date=row['applied_date'],
                follow_up_date=row['follow_up_date']
            )
            applications.append(app)

        return applications

    def export_to_json(self, filepath: str):
        """Exporta todas as candidaturas para JSON"""
        apps = self.get_all_applications()
        data = {
            "export_date": datetime.now().isoformat(),
            "applications": [app.to_dict() for app in apps],
            "statistics": self.get_statistics()
        }

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        logger.info(f"Exportado para: {filepath}")


def create_tracker(db_path: str = "applications.db") -> ApplicationTracker:
    """Cria instância do tracker"""
    return ApplicationTracker(db_path)
