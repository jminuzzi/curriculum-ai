"""
LinkedIn Job Matcher
Busca e faz matching automático com vagas do LinkedIn
"""

import json
import asyncio
import logging
from typing import List, Dict, Optional
from dataclasses import dataclass
from datetime import datetime
from playwright.async_api import async_playwright

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class JobListing:
    """Representa uma vaga encontrada"""
    title: str
    company: str
    location: str
    link: str
    description: str
    posted_date: str
    match_score: float = 0.0
    match_reasons: list = None

    def __post_init__(self):
        if self.match_reasons is None:
            self.match_reasons = []

    def to_dict(self):
        return {
            "title": self.title,
            "company": self.company,
            "location": self.location,
            "link": self.link,
            "description": self.description[:500] + "...",
            "posted_date": self.posted_date,
            "match_score": self.match_score,
            "match_reasons": self.match_reasons
        }


class LinkedInJobMatcher:
    """
    Busca vagas no LinkedIn e calcula match com perfil do candidato
    """

    LINKEDIN_JOBS_URL = "https://www.linkedin.com/jobs/search"

    def __init__(self, api_key: str = None):
        self.api_key = api_key
        self.jobs_found = []

    async def search_jobs(
        self,
        keywords: str,
        location: str = "Brasil",
        job_type: str = "F",  # F=Full-time, P=Part-time, C=Contract
        experience_level: str = None,  # 2=Entry, 3=Associate, 4=Mid, 5=Senior, 6=Executive
        remote: bool = True,
        max_results: int = 25
    ) -> List[JobListing]:
        """
        Busca vagas no LinkedIn

        Args:
            keywords: Palavras-chave (ex: "Python Developer")
            location: Localização
            job_type: Tipo de emprego
            experience_level: Nível de experiência
            remote: Incluir remotas
            max_results: Máximo de resultados
        """
        jobs = []

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context()
            page = await context.new_page()

            try:
                # Construir URL de busca
                search_params = f"?keywords={keywords.replace(' ', '%20')}"
                search_params += f"&location={location.replace(' ', '%20')}"

                if remote:
                    search_params += "&f_WT=2"  # Remote filter

                if experience_level:
                    search_params += f"&f_E={experience_level}"

                url = f"{self.LINKEDIN_JOBS_URL}{search_params}"
                logger.info(f"Buscando: {url}")

                await page.goto(url, wait_until="networkidle")
                await asyncio.sleep(3)

                # Extrair lista de vagas
                job_cards = await page.query_selector_all('.job-search-card, .jobs-search__results-list li')

                for i, card in enumerate(job_cards[:max_results]):
                    try:
                        job = await self._extract_job_data(card)
                        if job:
                            jobs.append(job)
                    except Exception as e:
                        logger.debug(f"Erro ao extrair vaga {i}: {e}")
                        continue

                logger.info(f"✅ {len(jobs)} vagas encontradas")

            except Exception as e:
                logger.error(f"Erro na busca: {e}")
            finally:
                await browser.close()

        self.jobs_found = jobs
        return jobs

    async def _extract_job_data(self, card) -> Optional[JobListing]:
        """Extrai dados de um card de vaga"""
        try:
            # Título
            title_elem = await card.query_selector('.job-search-card__title, .base-search-card__title')
            title = await title_elem.text_content() if title_elem else ""
            title = title.strip()

            # Empresa
            company_elem = await card.query_selector('.job-search-card__company-name, .base-search-card__subtitle')
            company = await company_elem.text_content() if company_elem else ""
            company = company.strip()

            # Localização
            location_elem = await card.query_selector('.job-search-card__location, .job-search-card__location')
            location = await location_elem.text_content() if location_elem else ""
            location = location.strip()

            # Link
            link_elem = await card.query_selector('a')
            link = await link_elem.get_attribute('href') if link_elem else ""
            if link and not link.startswith('http'):
                link = f"https://www.linkedin.com{link}"

            # Data
            date_elem = await card.query_selector('.job-search-card__listdate, time')
            posted_date = await date_elem.get_attribute('datetime') if date_elem else ""
            if not posted_date:
                posted_date = datetime.now().isoformat()

            return JobListing(
                title=title,
                company=company,
                location=location,
                link=link,
                description="",  # Será preenchido depois
                posted_date=posted_date
            )

        except Exception as e:
            logger.debug(f"Erro extração: {e}")
            return None

    async def calculate_match(
        self,
        jobs: List[JobListing],
        cv_data: Dict,
        min_score: float = 0.6
    ) -> List[JobListing]:
        """
        Calcula match entre vagas e currículo usando IA

        Args:
            jobs: Lista de vagas
            cv_data: Dados do currículo
            min_score: Score mínimo para incluir (0-1)
        """
        from openai import AsyncOpenAI

        if not self.api_key:
            logger.warning("API Key não fornecida, usando matching básico")
            return self._basic_matching(jobs, cv_data, min_score)

        client = AsyncOpenAI(api_key=self.api_key)
        matched_jobs = []

        cv_text = cv_data.get('raw_text', '')
        cv_skills = set([s.lower() for s in cv_data.get('habilidades', [])])

        for job in jobs:
            try:
                # Buscar descrição completa se não tiver
                if not job.description and job.link:
                    job.description = await self._get_job_description(job.link)

                # Usar IA para calcular match
                prompt = f"""Analise o match entre este candidato e vaga:

CANDIDATO:
{cv_text[:2000]}

VAGA:
Título: {job.title}
Empresa: {job.company}
Descrição: {job.description[:1500]}

Retorne JSON:
{{
    "match_score": 0.0-1.0,
    "reasons": ["por que é bom match"],
    "missing_skills": ["skills faltantes"],
    "recommendation": "apply|consider|skip"
}}"""

                response = await client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": "Você é um matcher de vagas especialista em RH."},
                        {"role": "user", "content": prompt}
                    ],
                    response_format={"type": "json_object"},
                    temperature=0.3
                )

                result = json.loads(response.choices[0].message.content)

                job.match_score = result.get("match_score", 0)
                job.match_reasons = result.get("reasons", [])

                if job.match_score >= min_score:
                    matched_jobs.append(job)

            except Exception as e:
                logger.debug(f"Erro no match: {e}")
                continue

        # Ordenar por score
        matched_jobs.sort(key=lambda x: x.match_score, reverse=True)

        return matched_jobs

    async def _get_job_description(self, job_url: str) -> str:
        """Busca descrição completa da vaga"""
        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                page = await browser.new_page()
                await page.goto(job_url, wait_until="networkidle")
                await asyncio.sleep(2)

                desc_elem = await page.query_selector('.description__text, .jobs-description__content')
                description = await desc_elem.text_content() if desc_elem else ""

                await browser.close()
                return description
        except:
            return ""

    def _basic_matching(self, jobs: List[JobListing], cv_data: Dict, min_score: float) -> List[JobListing]:
        """Matching básico por keywords (sem IA)"""
        cv_skills = set([s.lower() for s in cv_data.get('habilidades', [])])
        matched = []

        for job in jobs:
            job_text = f"{job.title} {job.description}".lower()
            matches = sum(1 for skill in cv_skills if skill in job_text)
            score = matches / max(len(cv_skills), 1)

            job.match_score = score
            if score >= min_score:
                job.match_reasons = [f"{matches} skills compatíveis encontradas"]
                matched.append(job)

        matched.sort(key=lambda x: x.match_score, reverse=True)
        return matched

    async def auto_apply(
        self,
        jobs: List[JobListing],
        cv_path: str,
        cover_letter_generator=None,
        max_applications: int = 5
    ) -> List[Dict]:
        """
        Candidata-se automaticamente às melhores vagas
        """
        results = []

        for job in jobs[:max_applications]:
            try:
                logger.info(f"🤖 Candidatando-se a: {job.title} na {job.company}")

                # Gerar cover letter se disponível
                cover_letter = None
                if cover_letter_generator:
                    cover_letter = await cover_letter_generator.generate(
                        cv_data={},  # Seria passado o cv real
                        job_description=job.description,
                        company_name=job.company
                    )

                # Aqui implementaria a automação de candidatura no LinkedIn
                # (requer login e interação complexa)

                results.append({
                    "job": job.to_dict(),
                    "status": "simulated",
                    "cover_letter": cover_letter.content if cover_letter else None
                })

            except Exception as e:
                results.append({
                    "job": job.to_dict(),
                    "status": "error",
                    "error": str(e)
                })

        return results


# Funções de conveniência
async def search_linkedin_jobs(
    keywords: str,
    api_key: str = None,
    **kwargs
) -> List[Dict]:
    """Busca simples de vagas no LinkedIn"""
    matcher = LinkedInJobMatcher(api_key)
    jobs = await matcher.search_jobs(keywords, **kwargs)
    return [j.to_dict() for j in jobs]


async def find_best_jobs(
    cv_data: Dict,
    keywords: str,
    api_key: str,
    min_score: float = 0.7
) -> List[Dict]:
    """Encontra as melhores vagas para o perfil"""
    matcher = LinkedInJobMatcher(api_key)
    jobs = await matcher.search_jobs(keywords)
    matched = await matcher.calculate_match(jobs, cv_data, min_score)
    return [j.to_dict() for j in matched]
