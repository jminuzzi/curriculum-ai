"""
Módulo de Otimização de Currículos com IA
Gera versões otimizadas para ATS e recrutadores
"""

import json
import os
import re
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime
from openai import AsyncOpenAI
import logging

# Para geração de PDF
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class OptimizedCV:
    """Currículo otimizado com metadados"""
    content_markdown: str
    content_html: str
    pdf_path: Optional[str] = None
    otimizacoes_aplicadas: List[str] = None
    palavras_chave_inseridas: List[str] = None
    score_original: int = 0
    score_otimizado: int = 0

    def __post_init__(self):
        if self.otimizacoes_aplicadas is None:
            self.otimizacoes_aplicadas = []
        if self.palavras_chave_inseridas is None:
            self.palavras_chave_inseridas = []


class CVOptimizer:
    """
    Otimizador profissional de currículos
    Transforma CVs comuns em documentos de alto impacto
    """

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o"):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.client = AsyncOpenAI(api_key=self.api_key)
        self.model = model

        # Templates de otimização
        self.templates = self._load_templates()

    def _load_templates(self) -> Dict[str, str]:
        """Carrega templates e instruções de otimização"""
        return {
            "system_optimizer": """
### ROLE ###
Você é um escritor executivo sênior especializado em currículos de alto impacto.
Já ajudou mais de 10.000 profissionais a conseguirem empregos em empresas como Google, Amazon, Microsoft e startups unicórnios.

### EXPERTISE ###
- ATS Optimization (95%+ de taxa de passagem)
- Storytelling profissional persuasivo
- Action-oriented writing
- Quantificação de resultados
- Keywords engineering

### PHILOSOPHY ###
"Não basta listar o que você fez. Precisa provar o impacto que causou."
""",

            "optimization_rules": """
### REGRAS DE OTIMIZAÇÃO OBRIGATÓRIAS ###

1. **ACTION VERBS**: Cada bullet deve começar com verbo de ação forte:
   ❌ "Responsável por vendas"
   ✅ "Aumentei receita em 150% através de estratégias de vendas consultivas"

2. **QUANTIFICAÇÃO**: Todo resultado deve ter número:
   ❌ "Melhorei processos"
   ✅ "Reduzi tempo de processamento de 5 dias para 2 horas (98% de ganho)"

3. **STAR METHOD**: Situação → Tarefa → Ação → Resultado

4. **KEYWORDS ATS**: Inserir palavras-chave da vaga naturalmente

5. **PARALLELISM**: Manter estrutura gramatical consistente

6. **ELIMINAÇÃO**: Remover:
   - Objetivos vagos
   - Responsabilidades sem resultado
   - Informações pessoais desnecessárias
   - Jargões sem contexto

7. **FORMATAÇÃO PROFISIONAL**:
   - Máximo 2 páginas
   - Fonte limpa (Arial/Calibri)
   - Espaçamento consistente
   - Seções claras
""",

            "output_format": """
### FORMATO DE SAÍDA ###
Retorne o currículo otimizado em formato Markdown estruturado:

```markdown
# [NOME COMPLETO]
[Cidade, Estado] | [Email] | [Telefone] | [LinkedIn]

## RESUMO PROFISSIONAL
[3-4 linhas de impacto com principais conquistas quantificadas]

## EXPERIÊNCIA PROFISSIONAL

### [Cargo] | [Empresa] | [Período]
- [Bullet com ação + métrica + resultado]
- [Bullet com ação + métrica + resultado]
- [Bullet com ação + métrica + resultado]

### [Cargo Anterior] | [Empresa] | [Período]
...

## FORMAÇÃO ACADÊMICA
- **[Curso]** - [Instituição] ([Ano])

## HABILIDADES TÉCNICAS
[Lista organizada por categorias]

## CERTIFICAÇÕES
- [Certificação relevante]

## IDIOMAS
- [Idioma] - [Nível]
```

Além do currículo, retorne um JSON com:
{
  "otimizacoes_aplicadas": ["..."],
  "palavras_chave_inseridas": ["..."],
  "score_estimado_original": 0-100,
  "score_estimado_otimizado": 0-100,
  "principais_mudancas": ["..."]
}
"""
        }

    async def optimize(
        self,
        cv_data: Dict,
        analysis_result: Dict,
        target_role: Optional[str] = None,
        job_description: Optional[str] = None,
        style: str = "professional"  # professional, creative, executive, tech
    ) -> OptimizedCV:
        """
        Otimiza o currículo baseado na análise

        Args:
            cv_data: Dados estruturados do CV original
            analysis_result: Resultado da análise de IA
            target_role: Cargo alvo
            job_description: Descrição da vaga
            style: Estilo do currículo otimizado
        """
        logger.info(f"Iniciando otimização para estilo: {style}")

        # Preparar contexto completo
        context = self._build_optimization_context(cv_data, analysis_result, target_role, job_description, style)

        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.templates["system_optimizer"]},
                    {"role": "user", "content": context}
                ],
                temperature=0.4,
                max_tokens=5000
            )

            content = response.choices[0].message.content

            # Extrair markdown e JSON
            cv_markdown, metadata = self._parse_optimization_response(content)

            # Converter para HTML
            cv_html = self._markdown_to_html(cv_markdown)

            # Criar objeto otimizado
            optimized = OptimizedCV(
                content_markdown=cv_markdown,
                content_html=cv_html,
                otimizacoes_aplicadas=metadata.get("otimizacoes_aplicadas", []),
                palavras_chave_inseridas=metadata.get("palavras_chave_inseridas", []),
                score_original=metadata.get("score_estimado_original", 0),
                score_otimizado=metadata.get("score_estimado_otimizado", 0)
            )

            logger.info(f"Otimização concluída - Score: {optimized.score_original} → {optimized.score_otimizado}")
            return optimized

        except Exception as e:
            logger.error(f"Erro na otimização: {str(e)}")
            raise

    def _build_optimization_context(
        self,
        cv_data: Dict,
        analysis: Dict,
        target_role: Optional[str],
        job_description: Optional[str],
        style: str
    ) -> str:
        """Constrói o contexto completo para otimização"""

        context = f"""
### CURRÍCULO ORIGINAL (PARA REESCREVER) ###
{cv_data.get('raw_text', '')}

### ANÁLISE DE PROBLEMAS IDENTIFICADOS ###
Erros Críticos:
{chr(10).join([f"- {e['descricao']}" for e in analysis.get('erros_criticos', [])])}

Pontos Fracos:
{chr(10).join([f"- {p}" for p in analysis.get('pontos_fracos', [])])}

Sugestões da Análise:
{chr(10).join([f"- {s['acao']}: {s.get('exemplo', '')}" for s in analysis.get('sugestoes', [])])}

Palavras-chave a inserir:
{chr(10).join(analysis.get('palavras_chave_faltantes', []))}

### PARÂMETROS DE OTIMIZAÇÃO ###
Estilo: {style}
Cargo Alvo: {target_role or 'Não especificado'}
"""

        if job_description:
            context += f"""
### DESCRIÇÃO DA VAGA (PARA ALINHAMENTO) ###
{job_description}
"""

        context += f"""
{self.templates["optimization_rules"]}

{self.templates["output_format"]}
"""

        return context

    def _parse_optimization_response(self, content: str) -> tuple:
        """Extrai currículo em markdown e metadados do JSON"""
        # Extrair markdown (entre ```markdown e ``` ou primeiro bloco)
        markdown_match = re.search(r'```markdown\n(.*?)```', content, re.DOTALL)
        if markdown_match:
            cv_markdown = markdown_match.group(1).strip()
        else:
            # Tentar extrair até o JSON
            json_start = content.find('{')
            if json_start > 0:
                cv_markdown = content[:json_start].strip()
            else:
                cv_markdown = content

        # Extrair JSON
        json_match = re.search(r'\{.*\}', content, re.DOTALL)
        if json_match:
            try:
                metadata = json.loads(json_match.group(0))
            except:
                metadata = {}
        else:
            metadata = {}

        return cv_markdown, metadata

    def _markdown_to_html(self, markdown: str) -> str:
        """Converte markdown básico para HTML"""
        html = markdown

        # Headers
        html = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)

        # Bold
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)

        # Listas
        html = re.sub(r'^- (.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
        html = re.sub(r'(<li>.*</li>\n)+', r'<ul>\g<0></ul>', html, flags=re.DOTALL)

        # Parágrafos
        html = re.sub(r'^(?!<[hlu])(.+)$', r'<p>\1</p>', html, flags=re.MULTILINE)

        return f"<html><body>{html}</body></html>"

    def generate_pdf(self, optimized_cv: OptimizedCV, output_path: str) -> str:
        """Gera PDF profissional do currículo otimizado"""

        doc = SimpleDocTemplate(
            output_path,
            pagesize=A4,
            rightMargin=2*cm,
            leftMargin=2*cm,
            topMargin=2*cm,
            bottomMargin=2*cm
        )

        styles = getSampleStyleSheet()
        story = []

        # Estilos personalizados
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            spaceAfter=12,
            textColor=colors.HexColor('#2c3e50')
        )

        heading2_style = ParagraphStyle(
            'CustomHeading2',
            parent=styles['Heading2'],
            fontSize=14,
            spaceAfter=6,
            textColor=colors.HexColor('#34495e'),
            borderColor=colors.HexColor('#3498db'),
            borderWidth=1,
            borderPadding=5
        )

        # Parse markdown e adicionar ao PDF
        lines = optimized_cv.content_markdown.split('\n')

        for line in lines:
            line = line.strip()
            if not line:
                story.append(Spacer(1, 0.2*cm))
                continue

            if line.startswith('# ') and not line.startswith('##'):
                # Título principal (nome)
                text = line.replace('# ', '')
                story.append(Paragraph(text, title_style))
                story.append(Spacer(1, 0.3*cm))

            elif line.startswith('## '):
                # Seções
                text = line.replace('## ', '')
                story.append(Paragraph(text, heading2_style))
                story.append(Spacer(1, 0.2*cm))

            elif line.startswith('### '):
                # Subseções (experiências)
                text = line.replace('### ', '')
                story.append(Paragraph(f"<b>{text}</b>", styles['Heading3']))

            elif line.startswith('- '):
                # Bullets
                text = line.replace('- ', '• ')
                story.append(Paragraph(text, styles['BodyText']))

            else:
                # Texto normal
                story.append(Paragraph(line, styles['BodyText']))

        doc.build(story)
        optimized_cv.pdf_path = output_path

        logger.info(f"PDF gerado: {output_path}")
        return output_path

    async def generate_tailored_versions(
        self,
        cv_data: Dict,
        analysis: Dict,
        job_descriptions: List[Dict]
    ) -> List[OptimizedCV]:
        """Gera versões personalizadas para múltiplas vagas"""
        versions = []

        for job in job_descriptions:
            optimized = await self.optimize(
                cv_data=cv_data,
                analysis_result=analysis,
                target_role=job.get('title'),
                job_description=job.get('description'),
                style=job.get('style', 'professional')
            )
            versions.append(optimized)

        return versions


# Funções de conveniência
async def optimize_cv(
    cv_data: Dict,
    analysis: Dict,
    api_key: Optional[str] = None,
    **kwargs
) -> Dict:
    """Função simples para otimização"""
    optimizer = CVOptimizer(api_key=api_key)
    result = await optimizer.optimize(cv_data, analysis, **kwargs)
    return {
        "markdown": result.content_markdown,
        "html": result.content_html,
        "otimizacoes": result.otimizacoes_aplicadas,
        "keywords": result.palavras_chave_inseridas,
        "score_improvement": f"{result.score_original} → {result.score_otimizado}"
    }


if __name__ == "__main__":
    import asyncio

    async def test():
        sample = {
            "raw_text": "João Silva\nAnalista de Sistemas\nExperiência em desenvolvimento",
            "nome": "João Silva"
        }
        analysis = {
            "erros_criticos": [],
            "pontos_fracos": ["Falta de métricas"],
            "sugestoes": [{"acao": "Adicionar números", "exemplo": "Aumentei eficiência em 50%"}],
            "palavras_chave_faltantes": ["Python", "Agile"]
        }

        optimizer = CVOptimizer()
        result = await optimizer.optimize(sample, analysis, target_role="Desenvolvedor Python")
        print(result.content_markdown[:500])

    asyncio.run(test())
