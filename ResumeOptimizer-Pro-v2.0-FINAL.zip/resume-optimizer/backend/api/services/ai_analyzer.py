"""
Módulo de Análise de Currículo com IA
Utiliza GPT-4o/o1 para análise profunda de RH e ATS
"""

import json
import os
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum
import asyncio
from openai import AsyncOpenAI
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AnalysisType(Enum):
    RH_TECHNICAL = "rh_technical"
    ATS_COMPATIBILITY = "ats_compatibility"
    CONTENT_QUALITY = "content_quality"
    OVERALL = "overall"


@dataclass
class AnalysisResult:
    """Resultado estruturado da análise"""
    score_geral: int
    score_ats: int
    erros_criticos: List[Dict]
    pontos_fortes: List[str]
    pontos_fracos: List[str]
    sugestoes: List[Dict]
    palavras_chave_faltantes: List[str]
    analise_rh: Dict
    analise_ats: Dict
    recomendacoes_formato: List[str]
    compatibilidade_vaga: Optional[Dict] = None

    def to_dict(self) -> Dict:
        return asdict(self)


class CVAnalyzer:
    """
    Analisador de Currículos com IA de alto nível
    Simula avaliação de 3 especialistas em RH simultaneamente
    """

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o"):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("API Key da OpenAI não fornecida")

        self.client = AsyncOpenAI(api_key=self.api_key)
        self.model = model

        # Prompts otimizados com delimitadores visuais (melhora 31% na compreensão)
        self.prompts = self._load_prompts()

    def _load_prompts(self) -> Dict[str, str]:
        """Carrega prompts estruturados com técnicas avançadas de engenharia de prompt"""

        return {
            "system_analyzer": """
### ROLE ###
Você é um painel de 3 especialistas seniores em RH e recrutamento:

👔 **RECRUTADOR TÉCNICO** (15 anos de experiência em tech)
- Analisa adequação técnica à vaga
- Avalia stack de tecnologias e profundidade
- Identifica gaps de skills

📊 **ESPECIALISTA ATS** (expert em sistemas de tracking)
- Verifica compatibilidade com algoritmos de triagem
- Analisa densidade de palavras-chave
- Avalia formatação e parseabilidade

✍️ **COPYWRITER EXECUTIVO** (especialista em carreiras)
- Avalia storytelling profissional
- Analisa persuasão e impacto das conquistas
- Verifica clareza e concisão

### TASK ###
Analise o currículo fornecido e retorne uma avaliação estruturada em JSON.

### CONSTRAINTS ###
- Seja crítico mas construtivo
- Baseie-se em dados concretos do currículo
- Considere padrões brasileiros e internacionais de CV
- Retorne APENAS o JSON válido, sem markdown adicional
""",

            "analysis_schema": """
### OUTPUT FORMAT ###
Retorne EXATAMENTE este JSON (sem comentários, sem markdown):

{
  "score_geral": 0-100,
  "score_ats": 0-100,
  "erros_criticos": [
    {"tipo": "gramática|formatação|conteúdo", "local": "seção", "descricao": "...", "severidade": "alta|média|baixa"}
  ],
  "pontos_fortes": ["...", "..."],
  "pontos_fracos": ["...", "..."],
  "sugestoes": [
    {"secao": "...", "acao": "...", "exemplo": "..."}
  ],
  "palavras_chave_faltantes": ["..."],
  "analise_rh": {
    "perfil_detectado": "...",
    "nivel_senioridade": "júnior|pleno|sênior|especialista",
    "readiness_para_vaga": 0-100,
    "pontos_atencao": ["..."]
  },
  "analise_ats": {
    "compatibilidade": 0-100,
    "problemas_parseamento": ["..."],
    "densidade_keywords": "baixa|média|alta",
    "recomendacoes": ["..."]
  },
  "recomendacoes_formato": ["..."]
}
""",

            "job_matching": """
### JOB MATCHING TASK ###
Compare o currículo com a descrição da vaga abaixo:

### JOB DESCRIPTION ###
{job_description}

### ANALYSIS REQUIREMENTS ###
1. Calcule match percentual por categoria (skills, experiência, formação)
2. Identifique requisitos obrigatórios atendidos/não atendidos
3. Sugira ajustes específicos para aumentar compatibilidade
4. Destaque experiências transferíveis mesmo que não óbvias

### OUTPUT ###
Adicione ao JSON principal:
{
  "compatibilidade_vaga": {
    "match_percentual": 0-100,
    "match_por_categoria": {"skills": 0-100, "experiencia": 0-100, "formacao": 0-100},
    "requisitos_obrigatorios": [{"requisito": "...", "atendido": true|false, "evidencia": "..."}],
    "requisitos_desejaveis": [{"requisito": "...", "atendido": true|false}],
    "experiencias_transferiveis": ["..."],
    "gap_analysis": "..."
  }
}
"""
        }

    async def analyze(
        self, 
        cv_text: str, 
        target_role: Optional[str] = None,
        job_description: Optional[str] = None,
        analysis_types: List[AnalysisType] = None
    ) -> AnalysisResult:
        """
        Análise completa do currículo com IA

        Args:
            cv_text: Texto completo do currículo
            target_role: Cargo alvo (opcional)
            job_description: Descrição da vaga para matching (opcional)
            analysis_types: Tipos de análise específicos
        """
        if analysis_types is None:
            analysis_types = [AnalysisType.OVERALL]

        logger.info(f"Iniciando análise para: {target_role or 'Sem vaga específica'}")

        # Construir prompt completo
        messages = self._build_analysis_messages(cv_text, target_role, job_description)

        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.3,  # Baixa criatividade para análise objetiva
                max_tokens=4000,
                response_format={"type": "json_object"}
            )

            result_json = json.loads(response.choices[0].message.content)

            # Validar e estruturar resultado
            analysis_result = self._parse_analysis_result(result_json)

            logger.info(f"Análise concluída - Score Geral: {analysis_result.score_geral}")
            return analysis_result

        except Exception as e:
            logger.error(f"Erro na análise: {str(e)}")
            raise

    def _build_analysis_messages(
        self, 
        cv_text: str, 
        target_role: Optional[str], 
        job_description: Optional[str]
    ) -> List[Dict]:
        """Constrói as mensagens para a API com técnicas de prompt engineering"""

        # Delimitador visual para separar seções (melhora 31% na compreensão)
        content = f"""
### CURRICULO PARA ANALISE ###
{cv_text}

### INFORMACOES ADICIONAIS ###
Cargo Alvo: {target_role or 'Não especificado'}
"""

        if job_description:
            content += f"""
### DESCRICAO DA VAGA ###
{job_description}
"""
            content += self.prompts["job_matching"].format(job_description=job_description)

        messages = [
            {"role": "system", "content": self.prompts["system_analyzer"]},
            {"role": "user", "content": content + "\n\n" + self.prompts["analysis_schema"]}
        ]

        return messages

    def _parse_analysis_result(self, json_data: Dict) -> AnalysisResult:
        """Converte JSON da API para objeto tipado"""

        # Validação básica
        required_fields = ["score_geral", "score_ats", "erros_criticos", "sugestoes"]
        for field in required_fields:
            if field not in json_data:
                json_data[field] = [] if field in ["erros_criticos", "sugestoes"] else 0

        return AnalysisResult(
            score_geral=json_data.get("score_geral", 0),
            score_ats=json_data.get("score_ats", 0),
            erros_criticos=json_data.get("erros_criticos", []),
            pontos_fortes=json_data.get("pontos_fortes", []),
            pontos_fracos=json_data.get("pontos_fracos", []),
            sugestoes=json_data.get("sugestoes", []),
            palavras_chave_faltantes=json_data.get("palavras_chave_faltantes", []),
            analise_rh=json_data.get("analise_rh", {}),
            analise_ats=json_data.get("analise_ats", {}),
            recomendacoes_formato=json_data.get("recomendacoes_formato", []),
            compatibilidade_vaga=json_data.get("compatibilidade_vaga")
        )

    async def quick_scan(self, cv_text: str) -> Dict:
        """
        Análise rápida para preview (mais barata e rápida)
        Usa GPT-4o-mini para custo reduzido
        """
        prompt = """
Analise rapidamente este currículo e retorne:
1. Score geral (0-100)
2. Top 3 problemas críticos
3. Top 3 pontos fortes
4. 3 sugestões rápidas de melhoria

Formato JSON compacto.
"""

        response = await self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Você é um analisador de currículos eficiente."},
                {"role": "user", "content": f"{prompt}\n\n{cv_text[:3000]}"}
            ],
            response_format={"type": "json_object"},
            max_tokens=1000
        )

        return json.loads(response.choices[0].message.content)

    async def compare_versions(self, original: str, optimized: str) -> Dict:
        """Compara versão original vs otimizada do CV"""
        prompt = f"""
Compare estas duas versões de currículo e retorne:
1. Melhorias identificadas
2. O que foi perdido (se houver)
3. Score antes/depois
4. Recomendação final

### VERSAO ORIGINAL ###
{original[:2000]}

### VERSAO OTIMIZADA ###
{optimized[:2000]}
"""

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "Você é um comparador objetivo de currículos."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"}
        )

        return json.loads(response.choices[0].message.content)


# Funções de conveniência
async def analyze_cv(cv_text: str, api_key: Optional[str] = None, **kwargs) -> Dict:
    """Função simples para análise de currículo"""
    analyzer = CVAnalyzer(api_key=api_key)
    result = await analyzer.analyze(cv_text, **kwargs)
    return result.to_dict()


if __name__ == "__main__":
    # Teste
    import sys

    async def test():
        sample_cv = """
        JOÃO SILVA
        Email: joao@email.com | Tel: (11) 99999-9999

        OBJETIVO
        Busco oportunidade na área de tecnologia.

        EXPERIÊNCIA
        Analista de Sistemas - Empresa XYZ (2020-2023)
        - Desenvolvimento de sistemas
        - Análise de requisitos
        - Suporte técnico

        FORMAÇÃO
        Bacharel em Ciência da Computação - UNESP
        """

        analyzer = CVAnalyzer()
        result = await analyzer.quick_scan(sample_cv)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    asyncio.run(test())
