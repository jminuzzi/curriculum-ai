#!/usr/bin/env python3
"""
Resume Optimizer - Versão Standalone
Executa diretamente sem necessidade de instalação prévia
"""

import os
import sys
import subprocess
import tempfile
import zipfile
import shutil
from pathlib import Path
from urllib.request import urlopen

class ResumeOptimizerApp:
    def __init__(self):
        self.temp_dir = None
        self.venv_dir = None

    def setup(self):
        """Configura ambiente temporário"""
        print("🔧 Configurando ambiente...")

        # Criar diretório temporário
        self.temp_dir = Path(tempfile.mkdtemp(prefix="resume_optimizer_"))
        self.venv_dir = self.temp_dir / "venv"

        # Criar ambiente virtual
        subprocess.run([sys.executable, "-m", "venv", str(self.venv_dir)], check=True)

        # Instalar dependências
        pip_cmd = str(self.venv_dir / "Scripts" / "pip") if os.name == 'nt' else str(self.venv_dir / "bin" / "pip")

        deps = [
            "streamlit", "openai", "pdfplumber", "reportlab", 
            "PyPDF2", "Pillow", "requests", "python-dotenv"
        ]

        subprocess.run([pip_cmd, "install", "-q"] + deps, check=True)

        print(f"✅ Ambiente configurado em: {self.temp_dir}")

    def create_minimal_app(self):
        """Cria versão minimalista da aplicação"""

        app_code = """
import streamlit as st
import os
from pathlib import Path

st.set_page_config(page_title="Resume Optimizer", layout="wide")

st.title("📄 Resume Optimizer Pro")
st.markdown("### Análise e Otimização de Currículos com IA")

# API Key
api_key = st.text_input("OpenAI API Key", type="password")
if api_key:
    os.environ["OPENAI_API_KEY"] = api_key

# Upload
uploaded = st.file_uploader("Upload do Currículo (PDF)", type=["pdf"])

if uploaded and api_key:
    st.success("Arquivo carregado! Processando...")

    # Salvar temporariamente
    temp_path = Path("temp_cv.pdf")
    temp_path.write_bytes(uploaded.getvalue())

    # Extrair texto simples
    try:
        import pdfplumber
        with pdfplumber.open(temp_path) as pdf:
            text = "\n".join([page.extract_text() or "" for page in pdf.pages])

        with st.expander("Texto Extraído"):
            st.text(text[:2000])

        # Análise simples com OpenAI
        if st.button("Analisar com IA"):
            with st.spinner("Analisando..."):
                from openai import OpenAI
                client = OpenAI(api_key=api_key)

                response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": "Você é um analisador de currículos. Forneça: 1) Score 0-100, 2) 3 pontos fortes, 3) 3 pontos fracos, 4) 3 sugestões de melhoria."},
                        {"role": "user", "content": f"Analise este currículo:\n\n{text[:4000]}"}
                    ]
                )

                st.markdown("### 📊 Análise")
                st.markdown(response.choices[0].message.content)

                # Otimização
                if st.button("Gerar Currículo Otimizado"):
                    with st.spinner("Otimizando..."):
                        opt_response = client.chat.completions.create(
                            model="gpt-4o-mini",
                            messages=[
                                {"role": "system", "content": "Reescreva este currículo de forma profissional, otimizado para ATS. Use bullets com métricas e action verbs."},
                                {"role": "user", "content": text[:4000]}
                            ]
                        )

                        st.markdown("### ✨ Versão Otimizada")
                        st.markdown(opt_response.choices[0].message.content)

                        st.download_button(
                            "Download TXT",
                            opt_response.choices[0].message.content,
                            "curriculo_otimizado.txt"
                        )

        temp_path.unlink()

    except Exception as e:
        st.error(f"Erro: {e}")

st.markdown("---")
st.markdown("<p style='text-align: center;'>Resume Optimizer Pro v1.0</p>", unsafe_allow_html=True)
"""

        app_path = self.temp_dir / "app.py"
        app_path.write_text(app_code, encoding="utf-8")
        return app_path

    def run(self):
        """Executa a aplicação"""
        try:
            self.setup()
            app_path = self.create_minimal_app()

            # Comando para executar Streamlit
            if os.name == 'nt':
                python_cmd = str(self.venv_dir / "Scripts" / "python")
            else:
                python_cmd = str(self.venv_dir / "bin" / "python")

            print("🚀 Iniciando aplicação...")
            subprocess.run([
                python_cmd, "-m", "streamlit", "run", str(app_path),
                "--server.port=8501"
            ])

        finally:
            # Limpar
            if self.temp_dir and self.temp_dir.exists():
                shutil.rmtree(self.temp_dir)
                print(f"🧹 Limpo: {self.temp_dir}")

def main():
    print("="*60)
    print("📄 RESUME OPTIMIZER - Modo Standalone")
    print("="*60)
    print("\nEste modo cria um ambiente temporário e executa a aplicação.")
    print("Aguarde a instalação das dependências...\n")

    app = ResumeOptimizerApp()
    app.run()

if __name__ == "__main__":
    main()
