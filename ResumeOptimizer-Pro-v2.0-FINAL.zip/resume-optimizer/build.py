#!/usr/bin/env python3
"""
Build script para criar executável do Resume Optimizer
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def clean_build():
    """Limpa builds anteriores"""
    dirs_to_remove = ['build', 'dist', '__pycache__', '*.spec']
    for pattern in dirs_to_remove:
        for path in Path('.').glob(pattern):
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
    print("✅ Build anterior limpo")

def install_pyinstaller():
    """Instala PyInstaller se necessário"""
    try:
        import PyInstaller
        print("✅ PyInstaller já instalado")
    except ImportError:
        print("📦 Instalando PyInstaller...")
        subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller"], check=True)

def create_executable():
    """Cria o executável"""
    print("🔨 Criando executável...")

    # Comando PyInstaller
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--name=ResumeOptimizer",
        "--onefile",  # Arquivo único
        "--windowed",  # Sem console (para GUI)
        "--icon=NONE",
        "--add-data", "backend:backend",
        "--add-data", "frontend:frontend",
        "--add-data", "automation:automation",
        "--add-data", "requirements.txt:.",
        "--hidden-import", "fastapi",
        "--hidden-import", "uvicorn",
        "--hidden-import", "streamlit",
        "--hidden-import", "openai",
        "--hidden-import", "pdfplumber",
        "--hidden-import", "reportlab",
        "--hidden-import", "playwright",
        "launcher.py"
    ]

    try:
        subprocess.run(cmd, check=True)
        print("✅ Executável criado em: dist/ResumeOptimizer")

        # Copiar arquivos adicionais
        dist_dir = Path("dist")
        if dist_dir.exists():
            shutil.copy("requirements.txt", dist_dir)
            shutil.copy(".env.example", dist_dir)
            print("✅ Arquivos adicionais copiados")

    except subprocess.CalledProcessError as e:
        print(f"❌ Erro ao criar executável: {e}")
        sys.exit(1)

def main():
    print("="*60)
    print("🔧 BUILD - Resume Optimizer")
    print("="*60)

    clean_build()
    install_pyinstaller()
    create_executable()

    print("\n" + "="*60)
    print("✅ BUILD CONCLUÍDO!")
    print("="*60)
    print("\nO executável está em: dist/ResumeOptimizer")
    print("\nPara distribuir:")
    print("  1. Copie a pasta 'dist' para o computador destino")
    print("  2. Execute: ./ResumeOptimizer (Linux/Mac) ou ResumeOptimizer.exe (Windows)")
    print("  3. Configure a API Key na interface")

if __name__ == "__main__":
    main()
