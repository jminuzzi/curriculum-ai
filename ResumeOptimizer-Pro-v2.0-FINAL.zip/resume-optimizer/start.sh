#!/bin/bash

echo "============================================"
echo "   RESUME OPTIMIZER PRO"
echo "   Analise e Otimize seu Curriculo com IA"
echo "============================================"
echo ""

# Verificar Python
if ! command -v python3 &> /dev/null
then
    echo "[ERRO] Python 3 não encontrado. Por favor, instale o Python 3.8+"
    exit 1
fi

# Criar ambiente virtual se não existir
if [ ! -d "venv" ]; then
    echo "[INFO] Criando ambiente virtual..."
    python3 -m venv venv
fi

echo "[INFO] Ativando ambiente virtual..."
source venv/bin/activate

echo "[INFO] Instalando dependências..."
pip install -q -r requirements.txt

echo "[INFO] Iniciando aplicação..."
python launcher.py
