from fastapi import FastAPI
from backend.api.routes import upload, analyze, optimize

app = FastAPI()

app.include_router(upload.router)
app.include_router(analyze.router)
app.include_router(optimize.router)

@app.get("/")
def root():
    return {"msg": "Resume Optimizer API running"}
