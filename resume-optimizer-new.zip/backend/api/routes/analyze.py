from fastapi import APIRouter

router = APIRouter()

@router.get("/analyze")
def analyze():
    return {"analysis": "Basic resume analysis done"}
