from fastapi import APIRouter, UploadFile
import os

router = APIRouter()

@router.post("/upload")
async def upload(file: UploadFile):
    path = f"data/uploads/{file.filename}"
    with open(path, "wb") as f:
        f.write(await file.read())
    return {"filename": file.filename}
