import streamlit as st
import requests

st.title("Resume Optimizer")

file = st.file_uploader("Upload CV")

if file:
    res = requests.post("http://localhost:8000/upload", files={"file": file})
    st.write(res.json())

if st.button("Analyze"):
    st.write(requests.get("http://localhost:8000/analyze").json())

if st.button("Optimize"):
    st.write(requests.get("http://localhost:8000/optimize").json())
