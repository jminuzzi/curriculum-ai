import os
os.system("pyinstaller --onefile frontend/app.py --name ResumeOptimizer")
